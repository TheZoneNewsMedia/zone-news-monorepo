/**
 * Scheduled Posting Service
 * Handles scheduling posts for future times with cron-like functionality
 */

const schedule = require('node-schedule');

class ScheduledPosting {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
        this.scheduledJobs = new Map();
        this.loadScheduledPosts();
    }

    /**
     * Register scheduled posting commands
     */
    register() {
        this.bot.command('schedule', this.handleSchedule.bind(this));
        this.bot.command('scheduled', this.handleViewScheduled.bind(this));
        this.bot.command('cancelschedule', this.handleCancelSchedule.bind(this));
        
        // Register callback handlers
        this.bot.action(/^schedule:/, this.handleScheduleCallback.bind(this));
    }

    /**
     * Handle /schedule command
     */
    async handleSchedule(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check if user has saved content
            const userState = await this.db.collection('user_states').findOne({ user_id: userId });
            const userMedia = await this.db.collection('user_media').find({ user_id: userId }).toArray();
            
            if (!userState?.post_text && userMedia.length === 0) {
                await ctx.reply(
                    '⏰ *Schedule a Post*\n\n' +
                    'You need content to schedule:\n' +
                    '• Use `/posttext` to set text\n' +
                    '• Send photos, videos, or documents\n' +
                    '• Use `/post` to create content first',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            // Show scheduling options
            await ctx.reply(
                '⏰ *Schedule Your Post*\n\n' +
                'When would you like to post?\n\n' +
                'Quick options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '⏱️ In 30 min', callback_data: 'schedule:30min' },
                                { text: '⏱️ In 1 hour', callback_data: 'schedule:1hour' }
                            ],
                            [
                                { text: '⏱️ In 3 hours', callback_data: 'schedule:3hours' },
                                { text: '⏱️ In 6 hours', callback_data: 'schedule:6hours' }
                            ],
                            [
                                { text: '🌅 Tomorrow 9 AM', callback_data: 'schedule:tomorrow9am' },
                                { text: '🌆 Tomorrow 6 PM', callback_data: 'schedule:tomorrow6pm' }
                            ],
                            [
                                { text: '📅 Custom Time', callback_data: 'schedule:custom' },
                                { text: '🔄 Recurring', callback_data: 'schedule:recurring' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error in schedule command:', error);
            await ctx.reply('❌ Error setting up schedule.');
        }
    }

    /**
     * Handle schedule callbacks
     */
    async handleScheduleCallback(ctx) {
        try {
            const action = ctx.callbackQuery.data.split(':')[1];
            const userId = ctx.from.id;
            
            let scheduledTime;
            const now = new Date();
            
            switch (action) {
                case '30min':
                    scheduledTime = new Date(now.getTime() + 30 * 60 * 1000);
                    break;
                case '1hour':
                    scheduledTime = new Date(now.getTime() + 60 * 60 * 1000);
                    break;
                case '3hours':
                    scheduledTime = new Date(now.getTime() + 3 * 60 * 60 * 1000);
                    break;
                case '6hours':
                    scheduledTime = new Date(now.getTime() + 6 * 60 * 60 * 1000);
                    break;
                case 'tomorrow9am':
                    scheduledTime = new Date(now);
                    scheduledTime.setDate(scheduledTime.getDate() + 1);
                    scheduledTime.setHours(9, 0, 0, 0);
                    break;
                case 'tomorrow6pm':
                    scheduledTime = new Date(now);
                    scheduledTime.setDate(scheduledTime.getDate() + 1);
                    scheduledTime.setHours(18, 0, 0, 0);
                    break;
                case 'custom':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '📅 *Custom Schedule*\n\n' +
                        'Send the date and time in this format:\n' +
                        '`YYYY-MM-DD HH:MM`\n\n' +
                        'Example: `2024-12-25 14:30`',
                        { parse_mode: 'Markdown' }
                    );
                    
                    // Set user state to await custom time
                    await this.db.collection('user_states').updateOne(
                        { user_id: userId },
                        { $set: { state: 'awaiting_schedule_time' } },
                        { upsert: true }
                    );
                    return;
                case 'recurring':
                    await ctx.answerCallbackQuery();
                    await this.showRecurringOptions(ctx);
                    return;
                default:
                    await ctx.answerCallbackQuery('Invalid option');
                    return;
            }
            
            // Create scheduled post
            await this.createScheduledPost(ctx, userId, scheduledTime);
            
            await ctx.answerCallbackQuery('✅ Post scheduled!');
            
        } catch (error) {
            console.error('Error handling schedule callback:', error);
            await ctx.answerCallbackQuery('❌ Error scheduling post');
        }
    }

    /**
     * Show recurring schedule options
     */
    async showRecurringOptions(ctx) {
        await ctx.reply(
            '🔄 *Recurring Schedule*\n\n' +
            'How often should this post repeat?',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '📅 Daily', callback_data: 'recurring:daily' },
                            { text: '📅 Weekly', callback_data: 'recurring:weekly' }
                        ],
                        [
                            { text: '📅 Weekdays', callback_data: 'recurring:weekdays' },
                            { text: '📅 Weekends', callback_data: 'recurring:weekends' }
                        ],
                        [
                            { text: '📅 Monthly', callback_data: 'recurring:monthly' },
                            { text: '📅 Custom', callback_data: 'recurring:custom' }
                        ],
                        [{ text: '❌ Cancel', callback_data: 'cancel' }]
                    ]
                }
            }
        );
    }

    /**
     * Create a scheduled post
     */
    async createScheduledPost(ctx, userId, scheduledTime, recurring = null) {
        try {
            // Get user content
            const userState = await this.db.collection('user_states').findOne({ user_id: userId });
            const userMedia = await this.db.collection('user_media').find({ user_id: userId }).toArray();
            
            // Get destinations
            const destinations = await this.db.collection('bot_destinations').find({
                $or: [
                    { type: 'group', bot_is_member: true },
                    { type: 'supergroup', bot_is_member: true },
                    { type: 'channel', bot_is_admin: true }
                ]
            }).toArray();
            
            if (destinations.length === 0) {
                await ctx.reply(
                    '⚠️ No destinations available for scheduling.\n' +
                    'Add the bot to groups or channels first.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            // Create scheduled post record
            const scheduledPost = {
                user_id: userId,
                scheduled_time: scheduledTime,
                recurring: recurring,
                content: {
                    text: userState?.post_text || null,
                    media: userMedia
                },
                destinations: destinations.map(d => ({
                    chat_id: d.chat_id,
                    title: d.title,
                    type: d.type
                })),
                status: 'scheduled',
                created_at: new Date()
            };
            
            const result = await this.db.collection('scheduled_posts').insertOne(scheduledPost);
            const postId = result.insertedId;
            
            // Schedule the job
            const job = schedule.scheduleJob(scheduledTime, async () => {
                await this.executeScheduledPost(postId);
            });
            
            this.scheduledJobs.set(postId.toString(), job);
            
            // Send confirmation
            const timeStr = scheduledTime.toLocaleString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            await ctx.reply(
                '✅ *Post Scheduled!*\n\n' +
                `📅 Time: ${timeStr}\n` +
                `📍 Destinations: ${destinations.length}\n` +
                (recurring ? `🔄 Recurring: ${recurring}\n` : '') +
                '\n' +
                'Use `/scheduled` to view all scheduled posts.',
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error creating scheduled post:', error);
            await ctx.reply('❌ Error scheduling post.');
        }
    }

    /**
     * Execute a scheduled post
     */
    async executeScheduledPost(postId) {
        try {
            const post = await this.db.collection('scheduled_posts').findOne({ _id: postId });
            
            if (!post || post.status !== 'scheduled') {
                return;
            }
            
            let successCount = 0;
            let failCount = 0;
            
            // Send to all destinations
            for (const dest of post.destinations) {
                try {
                    // Send text if available
                    if (post.content.text) {
                        await this.bot.telegram.sendMessage(dest.chat_id, post.content.text);
                    }
                    
                    // Send media if available
                    for (const media of post.content.media) {
                        await this.sendMedia(dest.chat_id, media);
                    }
                    
                    successCount++;
                } catch (err) {
                    console.error(`Failed to post to ${dest.title}:`, err);
                    failCount++;
                }
            }
            
            // Update post status
            await this.db.collection('scheduled_posts').updateOne(
                { _id: postId },
                {
                    $set: {
                        status: 'completed',
                        executed_at: new Date(),
                        results: { success: successCount, failed: failCount }
                    }
                }
            );
            
            // Notify user
            try {
                await this.bot.telegram.sendMessage(
                    post.user_id,
                    `✅ *Scheduled Post Executed*\n\n` +
                    `Successfully posted to ${successCount} destination(s)` +
                    (failCount > 0 ? `\n⚠️ Failed: ${failCount}` : ''),
                    { parse_mode: 'Markdown' }
                );
            } catch (err) {
                console.error('Could not notify user:', err);
            }
            
            // If recurring, schedule next occurrence
            if (post.recurring) {
                await this.scheduleNextRecurrence(post);
            }
            
            // Remove from active jobs
            this.scheduledJobs.delete(postId.toString());
            
        } catch (error) {
            console.error('Error executing scheduled post:', error);
        }
    }

    /**
     * Send media based on type
     */
    async sendMedia(chatId, media) {
        const options = media.caption ? { caption: media.caption } : {};
        
        switch (media.type) {
            case 'photo':
                await this.bot.telegram.sendPhoto(chatId, media.file_id, options);
                break;
            case 'video':
                await this.bot.telegram.sendVideo(chatId, media.file_id, options);
                break;
            case 'document':
                await this.bot.telegram.sendDocument(chatId, media.file_id, options);
                break;
            case 'audio':
                await this.bot.telegram.sendAudio(chatId, media.file_id, options);
                break;
            case 'voice':
                await this.bot.telegram.sendVoice(chatId, media.file_id, options);
                break;
            case 'animation':
                await this.bot.telegram.sendAnimation(chatId, media.file_id, options);
                break;
        }
    }

    /**
     * Handle /scheduled command - View scheduled posts
     */
    async handleViewScheduled(ctx) {
        try {
            const userId = ctx.from.id;
            
            const posts = await this.db.collection('scheduled_posts')
                .find({ user_id: userId, status: 'scheduled' })
                .sort({ scheduled_time: 1 })
                .toArray();
            
            if (posts.length === 0) {
                await ctx.reply(
                    '📅 *No Scheduled Posts*\n\n' +
                    'Use `/schedule` to schedule your first post.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            let message = '📅 *Your Scheduled Posts*\n\n';
            
            posts.forEach((post, index) => {
                const timeStr = post.scheduled_time.toLocaleString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
                
                message += `${index + 1}. 📍 ${timeStr}\n`;
                message += `   Destinations: ${post.destinations.length}\n`;
                if (post.recurring) {
                    message += `   🔄 ${post.recurring}\n`;
                }
                message += '\n';
            });
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '➕ Schedule New', callback_data: 'schedule:new' },
                            { text: '🗑️ Cancel All', callback_data: 'schedule:cancel:all' }
                        ],
                        [{ text: '❌ Close', callback_data: 'cancel' }]
                    ]
                }
            });
            
        } catch (error) {
            console.error('Error viewing scheduled posts:', error);
            await ctx.reply('❌ Error retrieving scheduled posts.');
        }
    }

    /**
     * Handle /cancelschedule command
     */
    async handleCancelSchedule(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Cancel all scheduled posts for user
            const posts = await this.db.collection('scheduled_posts')
                .find({ user_id: userId, status: 'scheduled' })
                .toArray();
            
            for (const post of posts) {
                const job = this.scheduledJobs.get(post._id.toString());
                if (job) {
                    job.cancel();
                    this.scheduledJobs.delete(post._id.toString());
                }
            }
            
            await this.db.collection('scheduled_posts').updateMany(
                { user_id: userId, status: 'scheduled' },
                { $set: { status: 'cancelled' } }
            );
            
            await ctx.reply(
                `✅ Cancelled ${posts.length} scheduled post(s).`,
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error cancelling scheduled posts:', error);
            await ctx.reply('❌ Error cancelling scheduled posts.');
        }
    }

    /**
     * Load scheduled posts on startup
     */
    async loadScheduledPosts() {
        try {
            const posts = await this.db.collection('scheduled_posts')
                .find({ status: 'scheduled', scheduled_time: { $gt: new Date() } })
                .toArray();
            
            for (const post of posts) {
                const job = schedule.scheduleJob(post.scheduled_time, async () => {
                    await this.executeScheduledPost(post._id);
                });
                
                this.scheduledJobs.set(post._id.toString(), job);
            }
            
            console.log(`✅ Loaded ${posts.length} scheduled posts`);
            
        } catch (error) {
            console.error('Error loading scheduled posts:', error);
        }
    }
}

module.exports = ScheduledPosting;