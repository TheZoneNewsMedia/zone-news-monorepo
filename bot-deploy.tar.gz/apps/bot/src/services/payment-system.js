/**
 * Payment System with Affiliate Program
 * Handles premium subscriptions and 20.5% affiliate commissions
 */

class PaymentSystem {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
        this.AFFILIATE_COMMISSION = 0.205; // 20.5% commission
        this.PAYMENT_PROVIDER_TOKEN = process.env.PAYMENT_PROVIDER_TOKEN;
        
        // Subscription tiers
        this.tiers = {
            basic: {
                name: 'Basic',
                price: 999, // $9.99 in cents
                features: [
                    'Unlimited posting',
                    'Basic analytics',
                    '5 scheduled posts',
                    'Priority support'
                ]
            },
            pro: {
                name: 'Pro',
                price: 1999, // $19.99
                features: [
                    'Everything in Basic',
                    'Advanced analytics',
                    'Unlimited scheduled posts',
                    'Media optimization',
                    'Custom branding'
                ]
            },
            enterprise: {
                name: 'Enterprise',
                price: 4999, // $49.99
                features: [
                    'Everything in Pro',
                    'API access',
                    'Team collaboration',
                    'White-label options',
                    'Dedicated support'
                ]
            }
        };
    }

    /**
     * Register payment commands
     */
    register() {
        // Subscription commands
        this.bot.command('subscribe', this.handleSubscribe.bind(this));
        this.bot.command('subscription', this.handleViewSubscription.bind(this));
        this.bot.command('cancel', this.handleCancelSubscription.bind(this));
        
        // Affiliate commands
        this.bot.command('affiliate', this.handleAffiliate.bind(this));
        this.bot.command('earnings', this.handleViewEarnings.bind(this));
        this.bot.command('withdraw', this.handleWithdraw.bind(this));
        
        // Payment handlers
        this.bot.on('pre_checkout_query', this.handlePreCheckout.bind(this));
        this.bot.on('successful_payment', this.handleSuccessfulPayment.bind(this));
        
        // Callback handlers
        this.bot.action(/^subscribe:/, this.handleSubscribeCallback.bind(this));
        this.bot.action(/^affiliate:/, this.handleAffiliateCallback.bind(this));
    }

    /**
     * Handle /subscribe command
     */
    async handleSubscribe(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check if user came through affiliate link
            const referralCode = ctx.startPayload;
            if (referralCode && referralCode.startsWith('ref_')) {
                await this.trackReferral(userId, referralCode);
            }
            
            let message = '💎 *Premium Subscriptions*\n\n';
            message += 'Unlock powerful features for your Zone News Bot:\n\n';
            
            // Show tier options
            const keyboard = [];
            
            for (const [key, tier] of Object.entries(this.tiers)) {
                keyboard.push([{
                    text: `${tier.name} - $${(tier.price / 100).toFixed(2)}/month`,
                    callback_data: `subscribe:${key}`
                }]);
            }
            
            keyboard.push([
                { text: '🎯 Compare Plans', callback_data: 'subscribe:compare' }
            ]);
            keyboard.push([
                { text: '💰 Affiliate Program', callback_data: 'affiliate:info' }
            ]);
            keyboard.push([
                { text: '❌ Cancel', callback_data: 'cancel' }
            ]);
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });
            
        } catch (error) {
            console.error('Error in subscribe command:', error);
            await ctx.reply('❌ Error loading subscription options.');
        }
    }

    /**
     * Handle subscription callbacks
     */
    async handleSubscribeCallback(ctx) {
        try {
            const action = ctx.callbackQuery.data.split(':')[1];
            
            if (action === 'compare') {
                await this.showComparison(ctx);
                return;
            }
            
            const tier = this.tiers[action];
            if (!tier) {
                await ctx.answerCallbackQuery('Invalid subscription tier');
                return;
            }
            
            await ctx.answerCallbackQuery();
            
            // Create invoice
            await this.createInvoice(ctx, action, tier);
            
        } catch (error) {
            console.error('Error handling subscribe callback:', error);
            await ctx.answerCallbackQuery('❌ Error processing subscription');
        }
    }

    /**
     * Create and send invoice
     */
    async createInvoice(ctx, tierKey, tier) {
        try {
            const userId = ctx.from.id;
            
            // Check for affiliate
            const referral = await this.db.collection('referrals').findOne({
                referred_user_id: userId,
                status: 'pending'
            });
            
            const invoice = {
                title: `${tier.name} Subscription`,
                description: `Monthly subscription to Zone News Bot ${tier.name} plan`,
                payload: JSON.stringify({
                    tier: tierKey,
                    user_id: userId,
                    referral_id: referral?._id?.toString()
                }),
                provider_token: this.PAYMENT_PROVIDER_TOKEN,
                currency: 'USD',
                prices: [
                    {
                        label: `${tier.name} Plan`,
                        amount: tier.price
                    }
                ],
                start_parameter: `sub_${tierKey}_${userId}`,
                photo_url: 'https://thezonenews.com/premium-badge.png',
                photo_width: 512,
                photo_height: 512,
                need_name: true,
                need_email: true,
                send_phone_number_to_provider: false,
                send_email_to_provider: true,
                is_flexible: false
            };
            
            await ctx.replyWithInvoice(invoice);
            
        } catch (error) {
            console.error('Error creating invoice:', error);
            await ctx.reply(
                '❌ Payment provider not configured.\n\n' +
                'Please contact support to set up premium subscription.',
                { parse_mode: 'Markdown' }
            );
        }
    }

    /**
     * Handle pre-checkout query
     */
    async handlePreCheckout(ctx) {
        try {
            // Validate the payment
            await ctx.answerPreCheckoutQuery(true);
        } catch (error) {
            console.error('Error in pre-checkout:', error);
            await ctx.answerPreCheckoutQuery(false, 'Payment validation failed');
        }
    }

    /**
     * Handle successful payment
     */
    async handleSuccessfulPayment(ctx) {
        try {
            const payment = ctx.message.successful_payment;
            const payload = JSON.parse(payment.invoice_payload);
            const userId = ctx.from.id;
            
            // Create subscription record
            const subscription = {
                user_id: userId,
                tier: payload.tier,
                amount: payment.total_amount,
                currency: payment.currency,
                telegram_payment_charge_id: payment.telegram_payment_charge_id,
                provider_payment_charge_id: payment.provider_payment_charge_id,
                started_at: new Date(),
                expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
                status: 'active'
            };
            
            await this.db.collection('subscriptions').insertOne(subscription);
            
            // Process affiliate commission if applicable
            if (payload.referral_id) {
                await this.processAffiliateCommission(payload.referral_id, payment.total_amount);
            }
            
            // Send confirmation
            const tier = this.tiers[payload.tier];
            await ctx.reply(
                '✅ *Payment Successful!*\n\n' +
                `Welcome to ${tier.name} plan! 🎉\n\n` +
                '*Your premium features are now active:*\n' +
                tier.features.map(f => `• ${f}`).join('\n') +
                '\n\n' +
                'Thank you for your subscription!',
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error handling successful payment:', error);
            await ctx.reply('✅ Payment received! Your subscription is being activated.');
        }
    }

    /**
     * Handle /affiliate command
     */
    async handleAffiliate(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Get or create affiliate account
            let affiliate = await this.db.collection('affiliates').findOne({ user_id: userId });
            
            if (!affiliate) {
                // Create new affiliate
                const code = `ref_${userId}_${Date.now().toString(36)}`;
                affiliate = {
                    user_id: userId,
                    username: ctx.from.username,
                    code: code,
                    total_earnings: 0,
                    pending_earnings: 0,
                    withdrawn: 0,
                    referrals: 0,
                    created_at: new Date()
                };
                
                await this.db.collection('affiliates').insertOne(affiliate);
            }
            
            const botUsername = ctx.botInfo.username;
            const affiliateLink = `https://t.me/${botUsername}?start=${affiliate.code}`;
            
            await ctx.reply(
                '💰 *Affiliate Program*\n\n' +
                '🎯 Earn 20.5% commission on every subscription!\n\n' +
                '*Your Affiliate Stats:*\n' +
                `• Total Earnings: $${(affiliate.total_earnings / 100).toFixed(2)}\n` +
                `• Pending: $${(affiliate.pending_earnings / 100).toFixed(2)}\n` +
                `• Referrals: ${affiliate.referrals}\n\n` +
                '*Your Affiliate Link:*\n' +
                `\`${affiliateLink}\`\n\n` +
                'Share this link to earn commissions!',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📊 View Details', callback_data: 'affiliate:details' },
                                { text: '💵 Withdraw', callback_data: 'affiliate:withdraw' }
                            ],
                            [
                                { text: '📈 Leaderboard', callback_data: 'affiliate:leaderboard' },
                                { text: '📋 Copy Link', callback_data: 'affiliate:copy' }
                            ],
                            [{ text: '❌ Close', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
            
        } catch (error) {
            console.error('Error in affiliate command:', error);
            await ctx.reply('❌ Error accessing affiliate program.');
        }
    }

    /**
     * Process affiliate commission
     */
    async processAffiliateCommission(referralId, amount) {
        try {
            const referral = await this.db.collection('referrals').findOne({
                _id: new require('mongodb').ObjectId(referralId)
            });
            
            if (!referral) return;
            
            const commission = Math.floor(amount * this.AFFILIATE_COMMISSION);
            
            // Update affiliate earnings
            await this.db.collection('affiliates').updateOne(
                { user_id: referral.affiliate_id },
                {
                    $inc: {
                        total_earnings: commission,
                        pending_earnings: commission,
                        referrals: 1
                    }
                }
            );
            
            // Create commission record
            await this.db.collection('commissions').insertOne({
                affiliate_id: referral.affiliate_id,
                referral_id: referralId,
                amount: commission,
                percentage: this.AFFILIATE_COMMISSION,
                original_amount: amount,
                status: 'pending',
                created_at: new Date()
            });
            
            // Update referral status
            await this.db.collection('referrals').updateOne(
                { _id: referral._id },
                { $set: { status: 'converted', converted_at: new Date() } }
            );
            
            // Notify affiliate
            try {
                await this.bot.telegram.sendMessage(
                    referral.affiliate_id,
                    `💰 *Commission Earned!*\n\n` +
                    `You earned $${(commission / 100).toFixed(2)} from a new subscription!\n` +
                    `Total earnings: $${((await this.getAffiliateEarnings(referral.affiliate_id)) / 100).toFixed(2)}`,
                    { parse_mode: 'Markdown' }
                );
            } catch (err) {
                console.error('Could not notify affiliate:', err);
            }
            
        } catch (error) {
            console.error('Error processing affiliate commission:', error);
        }
    }

    /**
     * Track referral
     */
    async trackReferral(userId, referralCode) {
        try {
            const affiliate = await this.db.collection('affiliates').findOne({ code: referralCode });
            
            if (!affiliate || affiliate.user_id === userId) {
                return; // Can't refer yourself
            }
            
            // Check if already referred
            const existing = await this.db.collection('referrals').findOne({
                referred_user_id: userId
            });
            
            if (existing) return;
            
            // Create referral record
            await this.db.collection('referrals').insertOne({
                affiliate_id: affiliate.user_id,
                referred_user_id: userId,
                referral_code: referralCode,
                status: 'pending',
                created_at: new Date()
            });
            
        } catch (error) {
            console.error('Error tracking referral:', error);
        }
    }

    /**
     * Get affiliate earnings
     */
    async getAffiliateEarnings(userId) {
        const affiliate = await this.db.collection('affiliates').findOne({ user_id: userId });
        return affiliate?.total_earnings || 0;
    }

    /**
     * Handle /earnings command
     */
    async handleViewEarnings(ctx) {
        try {
            const userId = ctx.from.id;
            const affiliate = await this.db.collection('affiliates').findOne({ user_id: userId });
            
            if (!affiliate) {
                await ctx.reply(
                    '💰 You\'re not enrolled in the affiliate program yet.\n' +
                    'Use `/affiliate` to get started!',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            // Get detailed commission history
            const commissions = await this.db.collection('commissions')
                .find({ affiliate_id: userId })
                .sort({ created_at: -1 })
                .limit(10)
                .toArray();
            
            let message = '💰 *Your Earnings*\n\n';
            message += `*Total Earned:* $${(affiliate.total_earnings / 100).toFixed(2)}\n`;
            message += `*Available:* $${(affiliate.pending_earnings / 100).toFixed(2)}\n`;
            message += `*Withdrawn:* $${(affiliate.withdrawn / 100).toFixed(2)}\n\n`;
            
            if (commissions.length > 0) {
                message += '*Recent Commissions:*\n';
                commissions.forEach(c => {
                    const date = c.created_at.toLocaleDateString();
                    message += `• $${(c.amount / 100).toFixed(2)} - ${date}\n`;
                });
            }
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '💵 Withdraw', callback_data: 'affiliate:withdraw' },
                            { text: '📊 Full Report', callback_data: 'affiliate:report' }
                        ],
                        [{ text: '❌ Close', callback_data: 'cancel' }]
                    ]
                }
            });
            
        } catch (error) {
            console.error('Error viewing earnings:', error);
            await ctx.reply('❌ Error retrieving earnings.');
        }
    }

    /**
     * Show subscription comparison
     */
    async showComparison(ctx) {
        let message = '📊 *Plan Comparison*\n\n';
        
        for (const [key, tier] of Object.entries(this.tiers)) {
            message += `*${tier.name} - $${(tier.price / 100).toFixed(2)}/month*\n`;
            tier.features.forEach(f => {
                message += `✓ ${f}\n`;
            });
            message += '\n';
        }
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            reply_markup: {
                inline_keyboard: [
                    [{ text: '« Back', callback_data: 'subscribe:menu' }],
                    [{ text: '❌ Close', callback_data: 'cancel' }]
                ]
            }
        });
    }
}

module.exports = PaymentSystem;