/**
 * Tier Manager - Controls feature access based on subscription level
 */

class TierManager {
    constructor(db) {
        this.db = db;
        
        // Define feature access by tier
        this.tiers = {
            free: {
                name: 'Free',
                commands: [
                    'start',
                    'help',
                    'news',
                    'subscribe',
                    'affiliate',
                    'post',           // Basic posting only
                    'mydestinations'
                ],
                limits: {
                    posts_per_day: 3,
                    scheduled_posts: 0,
                    media_size_mb: 5,
                    destinations: 1,
                    analytics_days: 0
                }
            },
            basic: {
                name: 'Basic',
                price: 999, // $9.99
                commands: [
                    'start',
                    'help',
                    'news',
                    'subscribe',
                    'affiliate',
                    'post',
                    'postmedia',      // Media posting
                    'schedule',       // Basic scheduling
                    'scheduled',
                    'mydestinations',
                    'earnings',
                    'quickpost'
                ],
                limits: {
                    posts_per_day: 50,
                    scheduled_posts: 5,
                    media_size_mb: 50,
                    destinations: 5,
                    analytics_days: 7
                }
            },
            pro: {
                name: 'Pro',
                price: 1999, // $19.99
                commands: [
                    'start',
                    'help',
                    'news',
                    'subscribe',
                    'affiliate',
                    'post',
                    'postmedia',
                    'posttogroup',    // Advanced posting
                    'posttochannel',
                    'schedule',
                    'scheduled',
                    'cancelschedule',
                    'mydestinations',
                    'checkbot',
                    'earnings',
                    'withdraw',
                    'quickpost',
                    'posttext',
                    'clearmedia',
                    'trending',       // Premium features
                    'analytics'
                ],
                limits: {
                    posts_per_day: 500,
                    scheduled_posts: 50,
                    media_size_mb: 200,
                    destinations: 50,
                    analytics_days: 30,
                    recurring_posts: true,
                    bulk_posting: true
                }
            },
            enterprise: {
                name: 'Enterprise',
                price: 4999, // $49.99
                commands: ['*'], // All commands
                limits: {
                    posts_per_day: -1,    // Unlimited
                    scheduled_posts: -1,   // Unlimited
                    media_size_mb: 1000,
                    destinations: -1,      // Unlimited
                    analytics_days: 365,
                    recurring_posts: true,
                    bulk_posting: true,
                    api_access: true,
                    white_label: true,
                    priority_support: true
                }
            }
        };
        
        // Premium-only commands with custom messages
        this.premiumCommands = {
            'postmedia': {
                minTier: 'basic',
                message: '📸 *Media Posting* is a premium feature.\n\nUpgrade to Basic ($9.99/mo) or higher to:\n• Post photos, videos, and documents\n• Schedule media posts\n• Batch upload multiple files'
            },
            'schedule': {
                minTier: 'basic',
                message: '⏰ *Scheduled Posting* is a premium feature.\n\nUpgrade to Basic ($9.99/mo) or higher to:\n• Schedule posts for later\n• Set recurring posts (Pro)\n• Manage content calendar'
            },
            'posttogroup': {
                minTier: 'pro',
                message: '📱 *Advanced Group Posting* is a Pro feature.\n\nUpgrade to Pro ($19.99/mo) to:\n• Post to multiple groups\n• Bulk posting\n• Advanced targeting'
            },
            'posttochannel': {
                minTier: 'pro',
                message: '📢 *Channel Management* is a Pro feature.\n\nUpgrade to Pro ($19.99/mo) to:\n• Manage multiple channels\n• Cross-post content\n• Channel analytics'
            },
            'analytics': {
                minTier: 'pro',
                message: '📊 *Analytics* is a Pro feature.\n\nUpgrade to Pro ($19.99/mo) to:\n• View detailed analytics\n• Export reports\n• Track engagement metrics'
            },
            'withdraw': {
                minTier: 'basic',
                message: '💵 *Withdrawals* require an active subscription.\n\nUpgrade to Basic ($9.99/mo) or higher to withdraw affiliate earnings.'
            },
            'bulkpost': {
                minTier: 'pro',
                message: '📤 *Bulk Posting* is a Pro feature.\n\nUpgrade to Pro ($19.99/mo) to post to multiple destinations simultaneously.'
            },
            'api': {
                minTier: 'enterprise',
                message: '🔌 *API Access* is an Enterprise feature.\n\nUpgrade to Enterprise ($49.99/mo) for:\n• Full API access\n• Webhook integrations\n• Custom workflows'
            },
            'export': {
                minTier: 'pro',
                message: '📁 *Export Features* are Pro features.\n\nUpgrade to Pro ($19.99/mo) to export data and analytics.'
            },
            'team': {
                minTier: 'enterprise',
                message: '👥 *Team Features* are Enterprise features.\n\nUpgrade to Enterprise ($49.99/mo) for:\n• Multi-admin support\n• Role management\n• Team analytics'
            }
        };
    }

    /**
     * Check if user has access to a command
     */
    async canUseCommand(userId, command) {
        try {
            // Get user's subscription tier
            const userTier = await this.getUserTier(userId);
            
            // Check if command is restricted
            const restriction = this.premiumCommands[command];
            if (!restriction) {
                // Not a restricted command, check tier's command list
                const tierConfig = this.tiers[userTier];
                if (tierConfig.commands.includes('*') || tierConfig.commands.includes(command)) {
                    return { allowed: true };
                }
                return { 
                    allowed: false, 
                    message: `Command /${command} is not available in ${tierConfig.name} tier.` 
                };
            }
            
            // Check tier level for restricted command
            const tierLevel = this.getTierLevel(userTier);
            const requiredLevel = this.getTierLevel(restriction.minTier);
            
            if (tierLevel >= requiredLevel) {
                return { allowed: true };
            }
            
            return {
                allowed: false,
                message: restriction.message,
                upgradeRequired: restriction.minTier
            };
            
        } catch (error) {
            console.error('Error checking command access:', error);
            return { allowed: true }; // Allow by default on error
        }
    }

    /**
     * Get user's subscription tier
     */
    async getUserTier(userId) {
        try {
            const subscription = await this.db.collection('subscriptions').findOne({
                user_id: userId,
                status: 'active',
                expires_at: { $gt: new Date() }
            });
            
            return subscription ? subscription.tier : 'free';
        } catch (error) {
            console.error('Error getting user tier:', error);
            return 'free';
        }
    }

    /**
     * Get tier level for comparison
     */
    getTierLevel(tierName) {
        const levels = {
            'free': 0,
            'basic': 1,
            'pro': 2,
            'enterprise': 3
        };
        return levels[tierName] || 0;
    }

    /**
     * Check if user has reached their limit
     */
    async checkLimit(userId, limitType, value = 1) {
        try {
            const userTier = await this.getUserTier(userId);
            const tierConfig = this.tiers[userTier];
            const limit = tierConfig.limits[limitType];
            
            // -1 means unlimited
            if (limit === -1) {
                return { allowed: true };
            }
            
            // Check usage based on limit type
            switch (limitType) {
                case 'posts_per_day':
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    
                    const postCount = await this.db.collection('post_history').countDocuments({
                        user_id: userId,
                        created_at: { $gte: today }
                    });
                    
                    if (postCount >= limit) {
                        return {
                            allowed: false,
                            message: `Daily post limit reached (${limit} posts/day).\n\nUpgrade to increase your limit.`,
                            current: postCount,
                            limit: limit
                        };
                    }
                    break;
                    
                case 'scheduled_posts':
                    const scheduledCount = await this.db.collection('scheduled_posts').countDocuments({
                        user_id: userId,
                        status: 'scheduled'
                    });
                    
                    if (scheduledCount >= limit) {
                        return {
                            allowed: false,
                            message: `Scheduled post limit reached (${limit} posts).\n\nUpgrade to schedule more posts.`,
                            current: scheduledCount,
                            limit: limit
                        };
                    }
                    break;
                    
                case 'media_size_mb':
                    if (value > limit) {
                        return {
                            allowed: false,
                            message: `File too large (max ${limit}MB for ${tierConfig.name} tier).\n\nUpgrade for larger file support.`,
                            current: value,
                            limit: limit
                        };
                    }
                    break;
                    
                case 'destinations':
                    const destinationCount = await this.db.collection('user_destinations').countDocuments({
                        user_id: userId
                    });
                    
                    if (destinationCount >= limit) {
                        return {
                            allowed: false,
                            message: `Destination limit reached (${limit} destinations).\n\nUpgrade to add more destinations.`,
                            current: destinationCount,
                            limit: limit
                        };
                    }
                    break;
            }
            
            return { allowed: true };
            
        } catch (error) {
            console.error('Error checking limit:', error);
            return { allowed: true };
        }
    }

    /**
     * Get user's usage stats
     */
    async getUserUsage(userId) {
        try {
            const userTier = await this.getUserTier(userId);
            const tierConfig = this.tiers[userTier];
            
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            const usage = {
                tier: tierConfig.name,
                limits: tierConfig.limits,
                current: {
                    posts_today: await this.db.collection('post_history').countDocuments({
                        user_id: userId,
                        created_at: { $gte: today }
                    }),
                    scheduled_posts: await this.db.collection('scheduled_posts').countDocuments({
                        user_id: userId,
                        status: 'scheduled'
                    }),
                    destinations: await this.db.collection('user_destinations').countDocuments({
                        user_id: userId
                    })
                }
            };
            
            return usage;
            
        } catch (error) {
            console.error('Error getting user usage:', error);
            return null;
        }
    }

    /**
     * Format tier comparison message
     */
    getTierComparison() {
        let message = '📊 *Subscription Tiers*\n\n';
        
        for (const [key, tier] of Object.entries(this.tiers)) {
            if (key === 'free') continue;
            
            message += `*${tier.name} - $${(tier.price / 100).toFixed(2)}/month*\n`;
            message += `• ${tier.limits.posts_per_day === -1 ? 'Unlimited' : tier.limits.posts_per_day} posts/day\n`;
            message += `• ${tier.limits.scheduled_posts === -1 ? 'Unlimited' : tier.limits.scheduled_posts} scheduled posts\n`;
            message += `• ${tier.limits.media_size_mb}MB media files\n`;
            message += `• ${tier.limits.destinations === -1 ? 'Unlimited' : tier.limits.destinations} destinations\n`;
            
            if (tier.limits.recurring_posts) {
                message += '• ✓ Recurring posts\n';
            }
            if (tier.limits.bulk_posting) {
                message += '• ✓ Bulk posting\n';
            }
            if (tier.limits.api_access) {
                message += '• ✓ API access\n';
            }
            if (tier.limits.white_label) {
                message += '• ✓ White label\n';
            }
            if (tier.limits.priority_support) {
                message += '• ✓ Priority support\n';
            }
            
            message += '\n';
        }
        
        return message;
    }

    /**
     * Middleware to check command access
     */
    createMiddleware() {
        return async (ctx, next) => {
            // Skip if not a command
            if (!ctx.message?.text?.startsWith('/')) {
                return next();
            }
            
            const command = ctx.message.text.split(' ')[0].substring(1).split('@')[0];
            const userId = ctx.from.id;
            
            // Check command access
            const access = await this.canUseCommand(userId, command);
            
            if (!access.allowed) {
                await ctx.reply(
                    access.message + '\n\nUse /subscribe to upgrade.',
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💎 View Plans', callback_data: 'subscribe:menu' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return; // Don't continue to next middleware
            }
            
            // Check rate limits for posting commands
            if (['post', 'quickpost', 'postmedia'].includes(command)) {
                const limitCheck = await this.checkLimit(userId, 'posts_per_day');
                if (!limitCheck.allowed) {
                    await ctx.reply(
                        limitCheck.message,
                        { 
                            parse_mode: 'Markdown',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '💎 Upgrade', callback_data: 'subscribe:menu' }],
                                    [{ text: '📊 View Usage', callback_data: 'usage:view' }],
                                    [{ text: '❌ Close', callback_data: 'cancel' }]
                                ]
                            }
                        }
                    );
                    return;
                }
            }
            
            return next();
        };
    }
}

module.exports = TierManager;