/**
 * Media Handler Service
 * Handles photo, video, document, and audio uploads for posting
 */

class MediaHandler {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
    }

    /**
     * Register media handlers
     */
    register() {
        // Handle photo uploads
        this.bot.on('photo', this.handlePhoto.bind(this));
        
        // Handle video uploads
        this.bot.on('video', this.handleVideo.bind(this));
        
        // Handle document uploads
        this.bot.on('document', this.handleDocument.bind(this));
        
        // Handle audio uploads
        this.bot.on('audio', this.handleAudio.bind(this));
        
        // Handle voice messages
        this.bot.on('voice', this.handleVoice.bind(this));
        
        // Register commands
        this.bot.command('postmedia', this.handlePostMedia.bind(this));
        this.bot.command('clearmedia', this.handleClearMedia.bind(this));
    }

    /**
     * Handle photo uploads
     */
    async handlePhoto(ctx) {
        try {
            const photos = ctx.message.photo;
            const largestPhoto = photos[photos.length - 1]; // Get highest resolution
            const caption = ctx.message.caption || '';
            
            // Store media for user
            await this.storeMedia(ctx.from.id, {
                type: 'photo',
                file_id: largestPhoto.file_id,
                caption: caption,
                file_unique_id: largestPhoto.file_unique_id,
                width: largestPhoto.width,
                height: largestPhoto.height,
                file_size: largestPhoto.file_size
            });
            
            await ctx.reply(
                '📸 *Photo saved!*\n\n' +
                (caption ? `Caption: "${caption}"\n\n` : '') +
                'Options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Post Now', callback_data: 'media:post:now' },
                                { text: '⏰ Schedule', callback_data: 'media:schedule' }
                            ],
                            [
                                { text: '➕ Add More Media', callback_data: 'media:add' },
                                { text: '✏️ Edit Caption', callback_data: 'media:caption' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error handling photo:', error);
            await ctx.reply('❌ Error saving photo. Please try again.');
        }
    }

    /**
     * Handle video uploads
     */
    async handleVideo(ctx) {
        try {
            const video = ctx.message.video;
            const caption = ctx.message.caption || '';
            
            // Store media for user
            await this.storeMedia(ctx.from.id, {
                type: 'video',
                file_id: video.file_id,
                caption: caption,
                file_unique_id: video.file_unique_id,
                duration: video.duration,
                width: video.width,
                height: video.height,
                file_size: video.file_size,
                mime_type: video.mime_type
            });
            
            await ctx.reply(
                '🎥 *Video saved!*\n\n' +
                `Duration: ${this.formatDuration(video.duration)}\n` +
                (caption ? `Caption: "${caption}"\n\n` : '\n') +
                'Options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Post Now', callback_data: 'media:post:now' },
                                { text: '⏰ Schedule', callback_data: 'media:schedule' }
                            ],
                            [
                                { text: '➕ Add More Media', callback_data: 'media:add' },
                                { text: '✏️ Edit Caption', callback_data: 'media:caption' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error handling video:', error);
            await ctx.reply('❌ Error saving video. Please try again.');
        }
    }

    /**
     * Handle document uploads
     */
    async handleDocument(ctx) {
        try {
            const document = ctx.message.document;
            const caption = ctx.message.caption || '';
            
            // Store media for user
            await this.storeMedia(ctx.from.id, {
                type: 'document',
                file_id: document.file_id,
                caption: caption,
                file_unique_id: document.file_unique_id,
                file_name: document.file_name,
                mime_type: document.mime_type,
                file_size: document.file_size
            });
            
            await ctx.reply(
                '📄 *Document saved!*\n\n' +
                `File: ${document.file_name}\n` +
                `Size: ${this.formatFileSize(document.file_size)}\n` +
                (caption ? `Caption: "${caption}"\n\n` : '\n') +
                'Options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Post Now', callback_data: 'media:post:now' },
                                { text: '⏰ Schedule', callback_data: 'media:schedule' }
                            ],
                            [
                                { text: '➕ Add More Media', callback_data: 'media:add' },
                                { text: '✏️ Edit Caption', callback_data: 'media:caption' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error handling document:', error);
            await ctx.reply('❌ Error saving document. Please try again.');
        }
    }

    /**
     * Handle audio uploads
     */
    async handleAudio(ctx) {
        try {
            const audio = ctx.message.audio;
            const caption = ctx.message.caption || '';
            
            // Store media for user
            await this.storeMedia(ctx.from.id, {
                type: 'audio',
                file_id: audio.file_id,
                caption: caption,
                file_unique_id: audio.file_unique_id,
                duration: audio.duration,
                performer: audio.performer,
                title: audio.title,
                mime_type: audio.mime_type,
                file_size: audio.file_size
            });
            
            await ctx.reply(
                '🎵 *Audio saved!*\n\n' +
                (audio.title ? `Title: ${audio.title}\n` : '') +
                (audio.performer ? `Artist: ${audio.performer}\n` : '') +
                `Duration: ${this.formatDuration(audio.duration)}\n` +
                (caption ? `Caption: "${caption}"\n\n` : '\n') +
                'Options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Post Now', callback_data: 'media:post:now' },
                                { text: '⏰ Schedule', callback_data: 'media:schedule' }
                            ],
                            [
                                { text: '➕ Add More Media', callback_data: 'media:add' },
                                { text: '✏️ Edit Caption', callback_data: 'media:caption' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error handling audio:', error);
            await ctx.reply('❌ Error saving audio. Please try again.');
        }
    }

    /**
     * Handle voice messages
     */
    async handleVoice(ctx) {
        try {
            const voice = ctx.message.voice;
            const caption = ctx.message.caption || '';
            
            // Store media for user
            await this.storeMedia(ctx.from.id, {
                type: 'voice',
                file_id: voice.file_id,
                caption: caption,
                file_unique_id: voice.file_unique_id,
                duration: voice.duration,
                mime_type: voice.mime_type,
                file_size: voice.file_size
            });
            
            await ctx.reply(
                '🎤 *Voice message saved!*\n\n' +
                `Duration: ${this.formatDuration(voice.duration)}\n` +
                (caption ? `Caption: "${caption}"\n\n` : '\n') +
                'Options:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Post Now', callback_data: 'media:post:now' },
                                { text: '⏰ Schedule', callback_data: 'media:schedule' }
                            ],
                            [
                                { text: '➕ Add More Media', callback_data: 'media:add' },
                                { text: '✏️ Edit Caption', callback_data: 'media:caption' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error handling voice:', error);
            await ctx.reply('❌ Error saving voice message. Please try again.');
        }
    }

    /**
     * Handle /postmedia command
     */
    async handlePostMedia(ctx) {
        try {
            const userId = ctx.from.id;
            const media = await this.getUserMedia(userId);
            
            if (media.length === 0) {
                await ctx.reply(
                    '📁 *No Media Saved*\n\n' +
                    'Send photos, videos, documents, or audio to get started.\n\n' +
                    'Supported formats:\n' +
                    '• Photos (JPG, PNG, etc.)\n' +
                    '• Videos (MP4, etc.)\n' +
                    '• Documents (PDF, DOC, etc.)\n' +
                    '• Audio files\n' +
                    '• Voice messages',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            let message = '📁 *Your Saved Media*\n\n';
            media.forEach((item, index) => {
                const emoji = this.getMediaEmoji(item.type);
                message += `${index + 1}. ${emoji} ${item.type}`;
                if (item.caption) {
                    message += ` - "${item.caption.substring(0, 30)}..."`;
                }
                message += '\n';
            });
            
            message += '\n*Select an action:*';
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '📤 Post All', callback_data: 'media:post:all' },
                            { text: '📤 Post Selected', callback_data: 'media:post:select' }
                        ],
                        [
                            { text: '⏰ Schedule', callback_data: 'media:schedule' },
                            { text: '🗑️ Clear All', callback_data: 'media:clear' }
                        ],
                        [{ text: '❌ Cancel', callback_data: 'cancel' }]
                    ]
                }
            });
        } catch (error) {
            console.error('Error in postmedia command:', error);
            await ctx.reply('❌ Error accessing saved media.');
        }
    }

    /**
     * Handle /clearmedia command
     */
    async handleClearMedia(ctx) {
        try {
            const userId = ctx.from.id;
            
            await this.db.collection('user_media').deleteMany({ user_id: userId });
            
            await ctx.reply(
                '🗑️ *Media Cleared*\n\n' +
                'All saved media has been removed.',
                { parse_mode: 'Markdown' }
            );
        } catch (error) {
            console.error('Error clearing media:', error);
            await ctx.reply('❌ Error clearing media.');
        }
    }

    /**
     * Store media for user
     */
    async storeMedia(userId, mediaData) {
        await this.db.collection('user_media').insertOne({
            user_id: userId,
            ...mediaData,
            created_at: new Date()
        });
    }

    /**
     * Get user's saved media
     */
    async getUserMedia(userId) {
        return await this.db.collection('user_media')
            .find({ user_id: userId })
            .sort({ created_at: -1 })
            .toArray();
    }

    /**
     * Format duration in seconds to readable format
     */
    formatDuration(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }

    /**
     * Format file size to readable format
     */
    formatFileSize(bytes) {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    }

    /**
     * Get emoji for media type
     */
    getMediaEmoji(type) {
        const emojis = {
            photo: '📸',
            video: '🎥',
            document: '📄',
            audio: '🎵',
            voice: '🎤'
        };
        return emojis[type] || '📁';
    }
}

module.exports = MediaHandler;