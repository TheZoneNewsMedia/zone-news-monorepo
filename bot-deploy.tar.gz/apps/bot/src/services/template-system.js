/**
 * Template System - Save and reuse post templates
 * Premium feature: Basic tier and above
 */

class TemplateSystem {
    constructor(bot, db, tierManager) {
        this.bot = bot;
        this.db = db;
        this.tierManager = tierManager;
        
        // Template limits by tier
        this.templateLimits = {
            free: 0,
            basic: 5,
            pro: 20,
            enterprise: -1 // Unlimited
        };
    }

    /**
     * Register template commands
     */
    register() {
        // Template commands
        this.bot.command('templates', this.handleTemplates.bind(this));
        this.bot.command('savetemplate', this.handleSaveTemplate.bind(this));
        this.bot.command('usetemplate', this.handleUseTemplate.bind(this));
        this.bot.command('deletetemplate', this.handleDeleteTemplate.bind(this));
        
        // Callback handlers
        this.bot.action(/^template:/, this.handleTemplateCallback.bind(this));
    }

    /**
     * Handle /templates command - View all templates
     */
    async handleTemplates(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check tier access
            const canUse = await this.tierManager.canUseCommand(userId, 'templates');
            if (!canUse.allowed) {
                await ctx.reply(canUse.message, { parse_mode: 'Markdown' });
                return;
            }
            
            const userTier = await this.tierManager.getUserTier(userId);
            const limit = this.templateLimits[userTier];
            
            // Get user's templates
            const templates = await this.db.collection('post_templates')
                .find({ user_id: userId })
                .sort({ created_at: -1 })
                .toArray();
            
            if (templates.length === 0) {
                await ctx.reply(
                    '📑 *No Templates Saved*\n\n' +
                    'Create templates to reuse your favorite post formats.\n\n' +
                    'Use `/savetemplate` after creating a post to save it as a template.',
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '➕ Create Template', callback_data: 'template:create' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            let message = '📑 *Your Templates*\n\n';
            if (limit !== -1) {
                message += `Using ${templates.length}/${limit} templates\n\n`;
            }
            
            const keyboard = [];
            
            templates.forEach((template, index) => {
                const emoji = this.getTemplateEmoji(template.type);
                keyboard.push([{
                    text: `${emoji} ${template.name}`,
                    callback_data: `template:view:${template._id}`
                }]);
            });
            
            // Add management buttons
            keyboard.push([
                { text: '➕ Create New', callback_data: 'template:create' },
                { text: '🗑️ Manage', callback_data: 'template:manage' }
            ]);
            
            if (userTier !== 'enterprise' && templates.length >= limit) {
                keyboard.push([{ text: '💎 Get More Templates', callback_data: 'subscribe:menu' }]);
            }
            
            keyboard.push([{ text: '❌ Close', callback_data: 'cancel' }]);
            
            message += 'Select a template to use or manage:';
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });
            
        } catch (error) {
            console.error('Error in templates command:', error);
            await ctx.reply('❌ Error loading templates.');
        }
    }

    /**
     * Handle /savetemplate command
     */
    async handleSaveTemplate(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check tier access
            const userTier = await this.tierManager.getUserTier(userId);
            if (userTier === 'free') {
                await ctx.reply(
                    '📑 *Templates* are a premium feature.\n\n' +
                    'Upgrade to Basic ($9.99/mo) or higher to save templates.',
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💎 Upgrade', callback_data: 'subscribe:menu' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            // Check template limit
            const limit = this.templateLimits[userTier];
            const templateCount = await this.db.collection('post_templates').countDocuments({ user_id: userId });
            
            if (limit !== -1 && templateCount >= limit) {
                await ctx.reply(
                    `📑 *Template Limit Reached*\n\n` +
                    `You have ${templateCount}/${limit} templates.\n\n` +
                    `Delete existing templates or upgrade for more.`,
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🗑️ Manage Templates', callback_data: 'template:manage' }],
                                [{ text: '💎 Upgrade', callback_data: 'subscribe:menu' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            // Get last post or saved content
            const userState = await this.db.collection('user_states').findOne({ user_id: userId });
            const userMedia = await this.db.collection('user_media').find({ user_id: userId }).toArray();
            
            if (!userState?.post_text && userMedia.length === 0) {
                await ctx.reply(
                    '📑 *Save Template*\n\n' +
                    'No content to save as template.\n\n' +
                    'Create a post first, then save it as a template.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            await ctx.reply(
                '📑 *Save as Template*\n\n' +
                'Enter a name for this template:',
                { parse_mode: 'Markdown' }
            );
            
            // Set user state to await template name
            await this.db.collection('user_states').updateOne(
                { user_id: userId },
                { 
                    $set: { 
                        state: 'awaiting_template_name',
                        template_content: {
                            text: userState?.post_text || null,
                            media: userMedia
                        }
                    } 
                },
                { upsert: true }
            );
            
        } catch (error) {
            console.error('Error in savetemplate command:', error);
            await ctx.reply('❌ Error saving template.');
        }
    }

    /**
     * Handle template callbacks
     */
    async handleTemplateCallback(ctx) {
        try {
            const parts = ctx.callbackQuery.data.split(':');
            const action = parts[1];
            const userId = ctx.from.id;
            
            switch (action) {
                case 'create':
                    await ctx.answerCallbackQuery();
                    await this.showCreateTemplate(ctx);
                    break;
                    
                case 'view':
                    const templateId = parts[2];
                    await ctx.answerCallbackQuery();
                    await this.viewTemplate(ctx, templateId);
                    break;
                    
                case 'use':
                    const useTemplateId = parts[2];
                    await this.useTemplate(ctx, useTemplateId);
                    break;
                    
                case 'edit':
                    const editTemplateId = parts[2];
                    await ctx.answerCallbackQuery();
                    await this.editTemplate(ctx, editTemplateId);
                    break;
                    
                case 'delete':
                    const deleteTemplateId = parts[2];
                    await this.deleteTemplate(ctx, deleteTemplateId);
                    break;
                    
                case 'manage':
                    await ctx.answerCallbackQuery();
                    await this.showManageTemplates(ctx);
                    break;
                    
                case 'duplicate':
                    const dupTemplateId = parts[2];
                    await this.duplicateTemplate(ctx, dupTemplateId);
                    break;
                    
                default:
                    await ctx.answerCallbackQuery('Unknown action');
            }
            
        } catch (error) {
            console.error('Error handling template callback:', error);
            await ctx.answerCallbackQuery('❌ Error processing template action');
        }
    }

    /**
     * Show create template interface
     */
    async showCreateTemplate(ctx) {
        await ctx.reply(
            '📑 *Create Template*\n\n' +
            'Choose template type:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '📝 Text Post', callback_data: 'template:type:text' },
                            { text: '📸 Media Post', callback_data: 'template:type:media' }
                        ],
                        [
                            { text: '📰 News Article', callback_data: 'template:type:news' },
                            { text: '📢 Announcement', callback_data: 'template:type:announcement' }
                        ],
                        [
                            { text: '🎯 Promotion', callback_data: 'template:type:promotion' },
                            { text: '📊 Report', callback_data: 'template:type:report' }
                        ],
                        [{ text: '❌ Cancel', callback_data: 'cancel' }]
                    ]
                }
            }
        );
    }

    /**
     * View template details
     */
    async viewTemplate(ctx, templateId) {
        try {
            const template = await this.db.collection('post_templates').findOne({
                _id: new require('mongodb').ObjectId(templateId),
                user_id: ctx.from.id
            });
            
            if (!template) {
                await ctx.reply('❌ Template not found.');
                return;
            }
            
            let message = `📑 *${template.name}*\n\n`;
            message += `Type: ${template.type}\n`;
            message += `Created: ${template.created_at.toLocaleDateString()}\n`;
            message += `Used: ${template.use_count || 0} times\n\n`;
            
            if (template.content.text) {
                message += `*Text:*\n${template.content.text.substring(0, 200)}`;
                if (template.content.text.length > 200) {
                    message += '...';
                }
                message += '\n\n';
            }
            
            if (template.content.media && template.content.media.length > 0) {
                message += `*Media:* ${template.content.media.length} file(s)\n`;
            }
            
            if (template.settings) {
                message += '\n*Settings:*\n';
                if (template.settings.schedule_time) {
                    message += `• Schedule: ${template.settings.schedule_time}\n`;
                }
                if (template.settings.destinations) {
                    message += `• Destinations: ${template.settings.destinations.length}\n`;
                }
            }
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '✅ Use Template', callback_data: `template:use:${templateId}` },
                            { text: '✏️ Edit', callback_data: `template:edit:${templateId}` }
                        ],
                        [
                            { text: '📋 Duplicate', callback_data: `template:duplicate:${templateId}` },
                            { text: '🗑️ Delete', callback_data: `template:delete:${templateId}` }
                        ],
                        [{ text: '« Back', callback_data: 'template:list' }],
                        [{ text: '❌ Close', callback_data: 'cancel' }]
                    ]
                }
            });
            
        } catch (error) {
            console.error('Error viewing template:', error);
            await ctx.reply('❌ Error loading template.');
        }
    }

    /**
     * Use a template
     */
    async useTemplate(ctx, templateId) {
        try {
            const template = await this.db.collection('post_templates').findOne({
                _id: new require('mongodb').ObjectId(templateId),
                user_id: ctx.from.id
            });
            
            if (!template) {
                await ctx.answerCallbackQuery('Template not found');
                return;
            }
            
            // Load template content into user state
            await this.db.collection('user_states').updateOne(
                { user_id: ctx.from.id },
                {
                    $set: {
                        post_text: template.content.text,
                        template_loaded: templateId,
                        updated_at: new Date()
                    }
                },
                { upsert: true }
            );
            
            // Load template media
            if (template.content.media && template.content.media.length > 0) {
                // Clear existing media
                await this.db.collection('user_media').deleteMany({ user_id: ctx.from.id });
                
                // Insert template media
                const mediaToInsert = template.content.media.map(m => ({
                    ...m,
                    user_id: ctx.from.id,
                    created_at: new Date()
                }));
                
                await this.db.collection('user_media').insertMany(mediaToInsert);
            }
            
            // Update use count
            await this.db.collection('post_templates').updateOne(
                { _id: template._id },
                { $inc: { use_count: 1 } }
            );
            
            await ctx.answerCallbackQuery('✅ Template loaded!');
            
            await ctx.reply(
                `✅ *Template Loaded*\n\n` +
                `Template: "${template.name}"\n\n` +
                `Ready to post! Use /post to continue.`,
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📤 Post Now', callback_data: 'post:start' }],
                            [{ text: '✏️ Edit Content', callback_data: 'template:edit:content' }],
                            [{ text: '⏰ Schedule', callback_data: 'schedule:start' }],
                            [{ text: '❌ Close', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
            
        } catch (error) {
            console.error('Error using template:', error);
            await ctx.answerCallbackQuery('❌ Error loading template');
        }
    }

    /**
     * Delete a template
     */
    async deleteTemplate(ctx, templateId) {
        try {
            const result = await this.db.collection('post_templates').deleteOne({
                _id: new require('mongodb').ObjectId(templateId),
                user_id: ctx.from.id
            });
            
            if (result.deletedCount > 0) {
                await ctx.answerCallbackQuery('✅ Template deleted');
                await this.handleTemplates(ctx); // Refresh list
            } else {
                await ctx.answerCallbackQuery('❌ Template not found');
            }
            
        } catch (error) {
            console.error('Error deleting template:', error);
            await ctx.answerCallbackQuery('❌ Error deleting template');
        }
    }

    /**
     * Duplicate a template
     */
    async duplicateTemplate(ctx, templateId) {
        try {
            const userId = ctx.from.id;
            const userTier = await this.tierManager.getUserTier(userId);
            const limit = this.templateLimits[userTier];
            
            // Check limit
            const templateCount = await this.db.collection('post_templates').countDocuments({ user_id: userId });
            
            if (limit !== -1 && templateCount >= limit) {
                await ctx.answerCallbackQuery(`Template limit reached (${limit})`);
                return;
            }
            
            const template = await this.db.collection('post_templates').findOne({
                _id: new require('mongodb').ObjectId(templateId),
                user_id: userId
            });
            
            if (!template) {
                await ctx.answerCallbackQuery('Template not found');
                return;
            }
            
            // Create duplicate
            delete template._id;
            template.name = `${template.name} (Copy)`;
            template.created_at = new Date();
            template.use_count = 0;
            
            await this.db.collection('post_templates').insertOne(template);
            
            await ctx.answerCallbackQuery('✅ Template duplicated');
            await this.handleTemplates(ctx); // Refresh list
            
        } catch (error) {
            console.error('Error duplicating template:', error);
            await ctx.answerCallbackQuery('❌ Error duplicating template');
        }
    }

    /**
     * Show manage templates interface
     */
    async showManageTemplates(ctx) {
        try {
            const userId = ctx.from.id;
            const templates = await this.db.collection('post_templates')
                .find({ user_id: userId })
                .sort({ created_at: -1 })
                .toArray();
            
            if (templates.length === 0) {
                await ctx.reply('No templates to manage.');
                return;
            }
            
            let message = '🗑️ *Manage Templates*\n\n';
            message += 'Select templates to delete:\n\n';
            
            const keyboard = templates.map(template => ([{
                text: `🗑️ ${template.name}`,
                callback_data: `template:delete:${template._id}`
            }]));
            
            keyboard.push([{ text: '« Back', callback_data: 'template:list' }]);
            keyboard.push([{ text: '❌ Close', callback_data: 'cancel' }]);
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            });
            
        } catch (error) {
            console.error('Error showing manage templates:', error);
            await ctx.reply('❌ Error loading templates.');
        }
    }

    /**
     * Get template emoji based on type
     */
    getTemplateEmoji(type) {
        const emojis = {
            text: '📝',
            media: '📸',
            news: '📰',
            announcement: '📢',
            promotion: '🎯',
            report: '📊'
        };
        return emojis[type] || '📑';
    }

    /**
     * Save user content as template
     */
    async saveAsTemplate(userId, name, type = 'custom') {
        try {
            const userState = await this.db.collection('user_states').findOne({ user_id: userId });
            const userMedia = await this.db.collection('user_media').find({ user_id: userId }).toArray();
            
            const template = {
                user_id: userId,
                name: name,
                type: type,
                content: {
                    text: userState?.post_text || null,
                    media: userMedia.map(m => ({
                        type: m.type,
                        file_id: m.file_id,
                        caption: m.caption
                    }))
                },
                settings: {
                    destinations: userState?.selected_destinations || [],
                    schedule_time: userState?.schedule_time || null
                },
                use_count: 0,
                created_at: new Date()
            };
            
            const result = await this.db.collection('post_templates').insertOne(template);
            return result.insertedId;
            
        } catch (error) {
            console.error('Error saving template:', error);
            return null;
        }
    }
}

module.exports = TemplateSystem;