/**
 * Bulk Edit System - Edit multiple posts/destinations at once
 * Premium feature: Pro tier and above
 */

class BulkEditSystem {
    constructor(bot, db, tierManager) {
        this.bot = bot;
        this.db = db;
        this.tierManager = tierManager;
        
        // Bulk operation limits by tier
        this.bulkLimits = {
            free: 0,
            basic: 5,
            pro: 50,
            enterprise: -1 // Unlimited
        };
    }

    /**
     * Register bulk edit commands
     */
    register() {
        // Bulk commands
        this.bot.command('bulk', this.handleBulk.bind(this));
        this.bot.command('bulkpost', this.handleBulkPost.bind(this));
        this.bot.command('bulkedit', this.handleBulkEdit.bind(this));
        this.bot.command('bulkdelete', this.handleBulkDelete.bind(this));
        this.bot.command('bulkschedule', this.handleBulkSchedule.bind(this));
        
        // Callback handlers
        this.bot.action(/^bulk:/, this.handleBulkCallback.bind(this));
    }

    /**
     * Handle /bulk command - Main bulk operations menu
     */
    async handleBulk(ctx) {
        try {
            const userId = ctx.from.id;
            const userTier = await this.tierManager.getUserTier(userId);
            
            if (userTier === 'free' || userTier === 'basic') {
                await ctx.reply(
                    '🔄 *Bulk Operations* are Pro features.\n\n' +
                    'Upgrade to Pro ($19.99/mo) or higher to:\n' +
                    '• Post to multiple destinations at once\n' +
                    '• Edit multiple posts simultaneously\n' +
                    '• Bulk schedule content\n' +
                    '• Mass delete posts',
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💎 Upgrade to Pro', callback_data: 'subscribe:pro' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            const limit = this.bulkLimits[userTier];
            
            await ctx.reply(
                '🔄 *Bulk Operations*\n\n' +
                `Bulk limit: ${limit === -1 ? 'Unlimited' : limit + ' items'}\n\n` +
                'Select operation:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📤 Bulk Post', callback_data: 'bulk:post' },
                                { text: '✏️ Bulk Edit', callback_data: 'bulk:edit' }
                            ],
                            [
                                { text: '⏰ Bulk Schedule', callback_data: 'bulk:schedule' },
                                { text: '🗑️ Bulk Delete', callback_data: 'bulk:delete' }
                            ],
                            [
                                { text: '📋 Bulk Templates', callback_data: 'bulk:templates' },
                                { text: '📍 Bulk Destinations', callback_data: 'bulk:destinations' }
                            ],
                            [{ text: '❌ Close', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
            
        } catch (error) {
            console.error('Error in bulk command:', error);
            await ctx.reply('❌ Error loading bulk operations.');
        }
    }

    /**
     * Handle /bulkpost command - Post to multiple destinations
     */
    async handleBulkPost(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check tier
            const access = await this.tierManager.canUseCommand(userId, 'bulkpost');
            if (!access.allowed) {
                await ctx.reply(access.message, { parse_mode: 'Markdown' });
                return;
            }
            
            // Get available destinations
            const destinations = await this.db.collection('bot_destinations').find({
                $or: [
                    { type: 'group', bot_is_member: true },
                    { type: 'supergroup', bot_is_member: true },
                    { type: 'channel', bot_is_admin: true }
                ]
            }).toArray();
            
            if (destinations.length === 0) {
                await ctx.reply(
                    '📍 No destinations available.\n\n' +
                    'Add the bot to groups or channels first.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            // Get user content
            const userState = await this.db.collection('user_states').findOne({ user_id: userId });
            const userMedia = await this.db.collection('user_media').find({ user_id: userId }).toArray();
            
            if (!userState?.post_text && userMedia.length === 0) {
                await ctx.reply(
                    '📤 *Bulk Post*\n\n' +
                    'No content to post.\n\n' +
                    'Use `/posttext` to set text or send media first.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            // Store bulk operation
            await this.db.collection('bulk_operations').insertOne({
                user_id: userId,
                type: 'post',
                content: {
                    text: userState?.post_text,
                    media: userMedia
                },
                destinations: destinations,
                status: 'pending',
                created_at: new Date()
            });
            
            await ctx.reply(
                '📤 *Bulk Post Ready*\n\n' +
                `Content: ${userState?.post_text ? 'Text' : ''} ${userMedia.length > 0 ? `+ ${userMedia.length} media` : ''}\n` +
                `Destinations: ${destinations.length}\n\n` +
                'Select destinations to post to:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '✅ All Destinations', callback_data: 'bulk:post:all' },
                                { text: '📱 Groups Only', callback_data: 'bulk:post:groups' }
                            ],
                            [
                                { text: '📢 Channels Only', callback_data: 'bulk:post:channels' },
                                { text: '✏️ Select Custom', callback_data: 'bulk:post:custom' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
            
        } catch (error) {
            console.error('Error in bulkpost command:', error);
            await ctx.reply('❌ Error setting up bulk post.');
        }
    }

    /**
     * Handle /bulkedit command - Edit multiple scheduled posts
     */
    async handleBulkEdit(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Check tier
            const userTier = await this.tierManager.getUserTier(userId);
            if (userTier === 'free' || userTier === 'basic') {
                await ctx.reply(
                    '✏️ *Bulk Edit* is a Pro feature.\n\n' +
                    'Upgrade to Pro ($19.99/mo) to edit multiple posts at once.',
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💎 Upgrade to Pro', callback_data: 'subscribe:pro' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            // Get scheduled posts
            const posts = await this.db.collection('scheduled_posts')
                .find({ user_id: userId, status: 'scheduled' })
                .sort({ scheduled_time: 1 })
                .toArray();
            
            if (posts.length === 0) {
                await ctx.reply(
                    '✏️ *Bulk Edit*\n\n' +
                    'No scheduled posts to edit.\n\n' +
                    'Schedule some posts first.',
                    { parse_mode: 'Markdown' }
                );
                return;
            }
            
            await ctx.reply(
                '✏️ *Bulk Edit Scheduled Posts*\n\n' +
                `Found ${posts.length} scheduled posts.\n\n` +
                'What would you like to edit?',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [
                                { text: '📝 Edit Text', callback_data: 'bulk:edit:text' },
                                { text: '⏰ Change Time', callback_data: 'bulk:edit:time' }
                            ],
                            [
                                { text: '📍 Change Destinations', callback_data: 'bulk:edit:destinations' },
                                { text: '🏷️ Add Tags', callback_data: 'bulk:edit:tags' }
                            ],
                            [
                                { text: '🔄 Convert to Template', callback_data: 'bulk:edit:template' },
                                { text: '📋 Duplicate All', callback_data: 'bulk:edit:duplicate' }
                            ],
                            [{ text: '❌ Cancel', callback_data: 'cancel' }]
                        ]
                    }
                }
            );
            
        } catch (error) {
            console.error('Error in bulkedit command:', error);
            await ctx.reply('❌ Error loading bulk edit.');
        }
    }

    /**
     * Handle bulk callbacks
     */
    async handleBulkCallback(ctx) {
        try {
            const parts = ctx.callbackQuery.data.split(':');
            const operation = parts[1];
            const subAction = parts[2];
            const userId = ctx.from.id;
            
            switch (operation) {
                case 'post':
                    await this.handleBulkPostCallback(ctx, subAction);
                    break;
                    
                case 'edit':
                    await this.handleBulkEditCallback(ctx, subAction);
                    break;
                    
                case 'schedule':
                    await this.handleBulkScheduleCallback(ctx, subAction);
                    break;
                    
                case 'delete':
                    await this.handleBulkDeleteCallback(ctx, subAction);
                    break;
                    
                case 'templates':
                    await this.handleBulkTemplatesCallback(ctx, subAction);
                    break;
                    
                case 'destinations':
                    await this.handleBulkDestinationsCallback(ctx, subAction);
                    break;
                    
                default:
                    await ctx.answerCallbackQuery('Unknown operation');
            }
            
        } catch (error) {
            console.error('Error handling bulk callback:', error);
            await ctx.answerCallbackQuery('❌ Error processing bulk operation');
        }
    }

    /**
     * Handle bulk post callbacks
     */
    async handleBulkPostCallback(ctx, action) {
        try {
            const userId = ctx.from.id;
            const bulkOp = await this.db.collection('bulk_operations').findOne({
                user_id: userId,
                type: 'post',
                status: 'pending'
            });
            
            if (!bulkOp) {
                await ctx.answerCallbackQuery('No pending bulk operation');
                return;
            }
            
            let destinations = [];
            
            switch (action) {
                case 'all':
                    destinations = bulkOp.destinations;
                    break;
                    
                case 'groups':
                    destinations = bulkOp.destinations.filter(d => 
                        d.type === 'group' || d.type === 'supergroup'
                    );
                    break;
                    
                case 'channels':
                    destinations = bulkOp.destinations.filter(d => d.type === 'channel');
                    break;
                    
                case 'custom':
                    await ctx.answerCallbackQuery();
                    await this.showDestinationSelector(ctx, bulkOp);
                    return;
            }
            
            if (destinations.length === 0) {
                await ctx.answerCallbackQuery('No destinations selected');
                return;
            }
            
            // Check bulk limit
            const userTier = await this.tierManager.getUserTier(userId);
            const limit = this.bulkLimits[userTier];
            
            if (limit !== -1 && destinations.length > limit) {
                await ctx.answerCallbackQuery(`Limit exceeded (max ${limit})`);
                await ctx.reply(
                    `⚠️ *Bulk Limit Exceeded*\n\n` +
                    `Your tier allows ${limit} destinations.\n` +
                    `Selected: ${destinations.length}\n\n` +
                    `Upgrade for higher limits.`,
                    { 
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '💎 Upgrade', callback_data: 'subscribe:menu' }],
                                [{ text: '❌ Close', callback_data: 'cancel' }]
                            ]
                        }
                    }
                );
                return;
            }
            
            await ctx.answerCallbackQuery('Posting...');
            
            // Execute bulk post
            const results = await this.executeBulkPost(bulkOp, destinations);
            
            // Update operation status
            await this.db.collection('bulk_operations').updateOne(
                { _id: bulkOp._id },
                {
                    $set: {
                        status: 'completed',
                        results: results,
                        completed_at: new Date()
                    }
                }
            );
            
            // Track usage
            await this.db.collection('post_history').insertOne({
                user_id: userId,
                type: 'bulk',
                destinations_count: destinations.length,
                success_count: results.success,
                failed_count: results.failed,
                created_at: new Date()
            });
            
            await ctx.editMessageText(
                `✅ *Bulk Post Complete*\n\n` +
                `Successfully posted to ${results.success} destination(s)\n` +
                (results.failed > 0 ? `⚠️ Failed: ${results.failed}\n` : '') +
                `\nTotal time: ${results.duration}s`,
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error in bulk post callback:', error);
            await ctx.answerCallbackQuery('❌ Error executing bulk post');
        }
    }

    /**
     * Execute bulk post operation
     */
    async executeBulkPost(operation, destinations) {
        const startTime = Date.now();
        let successCount = 0;
        let failCount = 0;
        const errors = [];
        
        // Process in batches to avoid rate limits
        const batchSize = 10;
        const batches = [];
        
        for (let i = 0; i < destinations.length; i += batchSize) {
            batches.push(destinations.slice(i, i + batchSize));
        }
        
        for (const batch of batches) {
            const promises = batch.map(async (dest) => {
                try {
                    // Send text if available
                    if (operation.content.text) {
                        await this.bot.telegram.sendMessage(dest.chat_id, operation.content.text);
                    }
                    
                    // Send media if available
                    for (const media of (operation.content.media || [])) {
                        await this.sendMedia(dest.chat_id, media);
                    }
                    
                    successCount++;
                } catch (err) {
                    failCount++;
                    errors.push({
                        destination: dest.title,
                        error: err.message
                    });
                }
            });
            
            await Promise.all(promises);
            
            // Small delay between batches to avoid rate limits
            if (batches.indexOf(batch) < batches.length - 1) {
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
        }
        
        const duration = Math.round((Date.now() - startTime) / 1000);
        
        return {
            success: successCount,
            failed: failCount,
            errors: errors,
            duration: duration
        };
    }

    /**
     * Handle bulk edit callbacks
     */
    async handleBulkEditCallback(ctx, action) {
        try {
            const userId = ctx.from.id;
            
            switch (action) {
                case 'text':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '✏️ *Edit Text*\n\n' +
                        'Enter the new text for all selected posts:',
                        { parse_mode: 'Markdown' }
                    );
                    
                    await this.db.collection('user_states').updateOne(
                        { user_id: userId },
                        { $set: { state: 'bulk_edit_text' } },
                        { upsert: true }
                    );
                    break;
                    
                case 'time':
                    await ctx.answerCallbackQuery();
                    await this.showBulkTimeOptions(ctx);
                    break;
                    
                case 'destinations':
                    await ctx.answerCallbackQuery();
                    await this.showBulkDestinationOptions(ctx);
                    break;
                    
                case 'duplicate':
                    await this.duplicateAllScheduled(ctx);
                    break;
                    
                case 'template':
                    await this.convertToTemplates(ctx);
                    break;
                    
                default:
                    await ctx.answerCallbackQuery('Unknown action');
            }
            
        } catch (error) {
            console.error('Error in bulk edit callback:', error);
            await ctx.answerCallbackQuery('❌ Error');
        }
    }

    /**
     * Show bulk time change options
     */
    async showBulkTimeOptions(ctx) {
        await ctx.reply(
            '⏰ *Bulk Reschedule*\n\n' +
            'How would you like to change the schedule?',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '⏩ Delay 1 hour', callback_data: 'bulk:time:delay:1h' },
                            { text: '⏩ Delay 1 day', callback_data: 'bulk:time:delay:1d' }
                        ],
                        [
                            { text: '⏪ Move earlier 1h', callback_data: 'bulk:time:earlier:1h' },
                            { text: '⏪ Move earlier 1d', callback_data: 'bulk:time:earlier:1d' }
                        ],
                        [
                            { text: '📅 Set specific time', callback_data: 'bulk:time:specific' },
                            { text: '🔄 Spread evenly', callback_data: 'bulk:time:spread' }
                        ],
                        [{ text: '❌ Cancel', callback_data: 'cancel' }]
                    ]
                }
            }
        );
    }

    /**
     * Duplicate all scheduled posts
     */
    async duplicateAllScheduled(ctx) {
        try {
            const userId = ctx.from.id;
            
            const posts = await this.db.collection('scheduled_posts')
                .find({ user_id: userId, status: 'scheduled' })
                .toArray();
            
            if (posts.length === 0) {
                await ctx.answerCallbackQuery('No posts to duplicate');
                return;
            }
            
            // Check limit
            const userTier = await this.tierManager.getUserTier(userId);
            const scheduledLimit = this.tierManager.tiers[userTier].limits.scheduled_posts;
            
            if (scheduledLimit !== -1) {
                const currentCount = posts.length;
                if (currentCount * 2 > scheduledLimit) {
                    await ctx.answerCallbackQuery(`Would exceed limit (${scheduledLimit})`);
                    return;
                }
            }
            
            // Duplicate posts
            const duplicates = posts.map(post => {
                const duplicate = { ...post };
                delete duplicate._id;
                duplicate.scheduled_time = new Date(post.scheduled_time.getTime() + 24 * 60 * 60 * 1000); // +1 day
                duplicate.created_at = new Date();
                duplicate.is_duplicate = true;
                duplicate.original_id = post._id;
                return duplicate;
            });
            
            await this.db.collection('scheduled_posts').insertMany(duplicates);
            
            await ctx.answerCallbackQuery('✅ Posts duplicated');
            await ctx.reply(
                `✅ *Duplicated ${posts.length} posts*\n\n` +
                'All posts have been duplicated and scheduled for +24 hours.',
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error duplicating posts:', error);
            await ctx.answerCallbackQuery('❌ Error duplicating');
        }
    }

    /**
     * Convert scheduled posts to templates
     */
    async convertToTemplates(ctx) {
        try {
            const userId = ctx.from.id;
            
            const posts = await this.db.collection('scheduled_posts')
                .find({ user_id: userId, status: 'scheduled' })
                .limit(5) // Limit to avoid too many templates
                .toArray();
            
            if (posts.length === 0) {
                await ctx.answerCallbackQuery('No posts to convert');
                return;
            }
            
            // Check template limit
            const userTier = await this.tierManager.getUserTier(userId);
            const templateLimit = userTier === 'enterprise' ? -1 : 
                                 userTier === 'pro' ? 20 : 
                                 userTier === 'basic' ? 5 : 0;
            
            if (templateLimit === 0) {
                await ctx.answerCallbackQuery('Templates not available in your tier');
                return;
            }
            
            const currentTemplates = await this.db.collection('post_templates').countDocuments({ user_id: userId });
            
            if (templateLimit !== -1 && currentTemplates + posts.length > templateLimit) {
                await ctx.answerCallbackQuery(`Would exceed template limit (${templateLimit})`);
                return;
            }
            
            // Convert to templates
            const templates = posts.map((post, index) => ({
                user_id: userId,
                name: `Scheduled Post ${index + 1}`,
                type: 'scheduled',
                content: post.content,
                settings: {
                    destinations: post.destinations,
                    schedule_time: post.scheduled_time
                },
                use_count: 0,
                created_at: new Date()
            }));
            
            await this.db.collection('post_templates').insertMany(templates);
            
            await ctx.answerCallbackQuery('✅ Converted to templates');
            await ctx.reply(
                `✅ *Created ${posts.length} templates*\n\n` +
                'Your scheduled posts have been saved as templates.',
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Error converting to templates:', error);
            await ctx.answerCallbackQuery('❌ Error converting');
        }
    }

    /**
     * Send media helper
     */
    async sendMedia(chatId, media) {
        const options = media.caption ? { caption: media.caption } : {};
        
        switch (media.type) {
            case 'photo':
                await this.bot.telegram.sendPhoto(chatId, media.file_id, options);
                break;
            case 'video':
                await this.bot.telegram.sendVideo(chatId, media.file_id, options);
                break;
            case 'document':
                await this.bot.telegram.sendDocument(chatId, media.file_id, options);
                break;
            case 'audio':
                await this.bot.telegram.sendAudio(chatId, media.file_id, options);
                break;
            case 'voice':
                await this.bot.telegram.sendVoice(chatId, media.file_id, options);
                break;
            case 'animation':
                await this.bot.telegram.sendAnimation(chatId, media.file_id, options);
                break;
        }
    }

    /**
     * Show destination selector for custom bulk post
     */
    async showDestinationSelector(ctx, bulkOp) {
        const keyboard = [];
        let row = [];
        
        bulkOp.destinations.forEach((dest, index) => {
            row.push({
                text: dest.title.substring(0, 20),
                callback_data: `bulk:select:${index}`
            });
            
            if (row.length === 2) {
                keyboard.push(row);
                row = [];
            }
        });
        
        if (row.length > 0) {
            keyboard.push(row);
        }
        
        keyboard.push([
            { text: '✅ Confirm Selection', callback_data: 'bulk:confirm' },
            { text: '❌ Cancel', callback_data: 'cancel' }
        ]);
        
        await ctx.reply(
            '📍 *Select Destinations*\n\n' +
            'Tap to toggle selection:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            }
        );
    }
}

module.exports = BulkEditSystem;