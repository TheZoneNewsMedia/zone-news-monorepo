/**
 * Onboarding Flow - Complete user journey from start
 * Handles About, Groups, Channels, and seamless navigation
 */

class OnboardingFlow {
    constructor(bot, db, tierManager) {
        this.bot = bot;
        this.db = db;
        this.tierManager = tierManager;
    }

    /**
     * Register onboarding handlers
     */
    register() {
        // Main commands
        this.bot.command('about', this.handleAbout.bind(this));
        this.bot.command('groups', this.handleGroups.bind(this));
        this.bot.command('channels', this.handleChannels.bind(this));
        this.bot.command('demo', this.handleDemo.bind(this));
        this.bot.command('tutorial', this.handleTutorial.bind(this));
        
        // Callback handlers
        this.bot.action(/^about:/, this.handleAboutCallback.bind(this));
        this.bot.action(/^groups:/, this.handleGroupsCallback.bind(this));
        this.bot.action(/^channels:/, this.handleChannelsCallback.bind(this));
        this.bot.action(/^onboard:/, this.handleOnboardCallback.bind(this));
        this.bot.action('back:main', this.backToMain.bind(this));
    }

    /**
     * Handle About button/command
     */
    async handleAbout(ctx) {
        try {
            const userId = ctx.from.id;
            const userTier = await this.tierManager.getUserTier(userId);
            
            let message = '📖 *About Zone News Bot*\n\n';
            message += '🎯 *Our Mission*\n';
            message += 'Empowering content creators and news aggregators with powerful automation tools.\n\n';
            
            message += '✨ *Key Features*\n';
            message += '• 📰 News aggregation from multiple sources\n';
            message += '• 📤 Automated posting to groups/channels\n';
            message += '• ⏰ Advanced scheduling system\n';
            message += '• 📸 Rich media support\n';
            message += '• 💰 Monetization through affiliates\n';
            message += '• 📊 Analytics and insights\n\n';
            
            message += '🏆 *Why Choose Us?*\n';
            message += '• Trusted by 1000+ channels\n';
            message += '• 99.9% uptime guarantee\n';
            message += '• 24/7 automated posting\n';
            message += '• Adelaide & South Australia focus\n\n';
            
            message += `📱 *Your Status*\n`;
            message += `Tier: ${this.tierManager.tiers[userTier].name}\n`;
            
            const stats = await this.getUserStats(userId);
            if (stats) {
                message += `Posts Today: ${stats.postsToday}\n`;
                message += `Total Posts: ${stats.totalPosts}\n`;
            }
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🚀 Quick Start', callback_data: 'onboard:quickstart' },
                            { text: '📹 Watch Demo', callback_data: 'about:demo' }
                        ],
                        [
                            { text: '💎 View Plans', callback_data: 'subscribe:menu' },
                            { text: '💰 Earn Money', callback_data: 'affiliate:info' }
                        ],
                        [
                            { text: '📞 Contact Support', url: 'https://t.me/ZoneNewsSupport' },
                            { text: '📚 Documentation', callback_data: 'about:docs' }
                        ],
                        [{ text: '« Back to Menu', callback_data: 'back:main' }]
                    ]
                }
            });
            
        } catch (error) {
            console.error('Error in about:', error);
            await ctx.reply('❌ Error loading about page.');
        }
    }

    /**
     * Handle Groups button - Show available groups to join/post
     */
    async handleGroups(ctx) {
        try {
            const userId = ctx.from.id;
            const userTier = await this.tierManager.getUserTier(userId);
            
            // Get bot's current groups
            const botGroups = await this.db.collection('bot_destinations').find({
                type: { $in: ['group', 'supergroup'] },
                bot_is_member: true
            }).toArray();
            
            let message = '📱 *Groups & Communities*\n\n';
            
            if (botGroups.length > 0) {
                message += '*📍 Active Groups:*\n';
                botGroups.slice(0, 5).forEach(g => {
                    message += `• ${g.title}\n`;
                });
                if (botGroups.length > 5) {
                    message += `_...and ${botGroups.length - 5} more_\n`;
                }
                message += '\n';
            }
            
            message += '*🌟 Featured Groups:*\n';
            message += '• 📰 Zone News Discussion\n';
            message += '• 🏛️ Adelaide Politics\n';
            message += '• 🏀 SA Sports Talk\n';
            message += '• 💼 Business Network SA\n';
            message += '• 🎭 Adelaide Events\n\n';
            
            message += '*🎯 What You Can Do:*\n';
            
            if (userTier === 'free') {
                message += '• View news in groups (Free)\n';
                message += '• 🔒 Post to groups (Basic+)\n';
                message += '• 🔒 Manage multiple groups (Pro+)\n';
            } else if (userTier === 'basic') {
                message += '• ✅ Post to groups\n';
                message += '• ✅ Schedule posts\n';
                message += '• 🔒 Bulk posting (Pro+)\n';
            } else {
                message += '• ✅ Post to unlimited groups\n';
                message += '• ✅ Bulk operations\n';
                message += '• ✅ Advanced analytics\n';
            }
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '➕ Add Bot to Group', callback_data: 'groups:howto' },
                            { text: '📤 Post Now', callback_data: 'post:start' }
                        ],
                        [
                            { text: '🔍 Find Groups', callback_data: 'groups:discover' },
                            { text: '📊 Group Stats', callback_data: 'groups:stats' }
                        ],
                        userTier === 'free' ? 
                            [{ text: '🔓 Unlock Posting', callback_data: 'subscribe:basic' }] : [],
                        [{ text: '« Back to Menu', callback_data: 'back:main' }]
                    ].filter(row => row.length > 0)
                }
            });
            
        } catch (error) {
            console.error('Error in groups:', error);
            await ctx.reply('❌ Error loading groups.');
        }
    }

    /**
     * Handle Channels button - Show channels to follow/manage
     */
    async handleChannels(ctx) {
        try {
            const userId = ctx.from.id;
            const userTier = await this.tierManager.getUserTier(userId);
            
            // Get bot's channels
            const botChannels = await this.db.collection('bot_destinations').find({
                type: 'channel',
                bot_is_admin: true
            }).toArray();
            
            let message = '📢 *Channels & Broadcasting*\n\n';
            
            if (botChannels.length > 0) {
                message += '*📍 Active Channels:*\n';
                botChannels.slice(0, 5).forEach(c => {
                    message += `• ${c.title}\n`;
                });
                if (botChannels.length > 5) {
                    message += `_...and ${botChannels.length - 5} more_\n`;
                }
                message += '\n';
            }
            
            message += '*🌟 Popular Channels:*\n';
            message += '• 📺 @ZoneNewsAdl - Main news\n';
            message += '• 🏛️ @AdelaidePolitics - Politics\n';
            message += '• 🏀 @SASportsNews - Sports\n';
            message += '• 💼 @SABusiness - Business\n';
            message += '• 🎭 @AdelaideEvents - Events\n\n';
            
            message += '*📊 Channel Features:*\n';
            
            if (userTier === 'free') {
                message += '• Follow channels (Free)\n';
                message += '• 🔒 Create channel (Basic+)\n';
                message += '• 🔒 Auto-post to channels (Pro+)\n';
                message += '• 🔒 Analytics (Pro+)\n';
            } else if (userTier === 'basic') {
                message += '• ✅ Manage 1 channel\n';
                message += '• ✅ Schedule posts\n';
                message += '• 🔒 Multiple channels (Pro+)\n';
                message += '• 🔒 Analytics (Pro+)\n';
            } else {
                message += '• ✅ Unlimited channels\n';
                message += '• ✅ Cross-posting\n';
                message += '• ✅ Advanced analytics\n';
                message += '• ✅ Auto-posting\n';
            }
            
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '➕ Add Bot to Channel', callback_data: 'channels:howto' },
                            { text: '📤 Post to Channel', callback_data: 'posttochannel' }
                        ],
                        [
                            { text: '📈 Channel Growth Tips', callback_data: 'channels:tips' },
                            { text: '📊 Analytics', callback_data: 'channels:analytics' }
                        ],
                        userTier === 'free' ? 
                            [{ text: '🔓 Unlock Channels', callback_data: 'subscribe:basic' }] : [],
                        [{ text: '« Back to Menu', callback_data: 'back:main' }]
                    ].filter(row => row.length > 0)
                }
            });
            
        } catch (error) {
            console.error('Error in channels:', error);
            await ctx.reply('❌ Error loading channels.');
        }
    }

    /**
     * Handle Demo - Interactive demonstration
     */
    async handleDemo(ctx) {
        try {
            await ctx.reply(
                '🎬 *Interactive Demo*\n\n' +
                'Let me show you what I can do!\n\n' +
                'Choose a demo:',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '📤 Posting Demo', callback_data: 'onboard:demo:post' }],
                            [{ text: '⏰ Scheduling Demo', callback_data: 'onboard:demo:schedule' }],
                            [{ text: '📸 Media Demo', callback_data: 'onboard:demo:media' }],
                            [{ text: '📑 Templates Demo', callback_data: 'onboard:demo:template' }],
                            [{ text: '💰 Earnings Demo', callback_data: 'onboard:demo:earnings' }],
                            [{ text: '« Back', callback_data: 'back:main' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error in demo:', error);
            await ctx.reply('❌ Error loading demo.');
        }
    }

    /**
     * Handle Tutorial - Step-by-step guide
     */
    async handleTutorial(ctx) {
        try {
            const userId = ctx.from.id;
            
            // Mark tutorial as started
            await this.db.collection('user_states').updateOne(
                { user_id: userId },
                { 
                    $set: { 
                        tutorial_step: 1,
                        tutorial_started: new Date()
                    } 
                },
                { upsert: true }
            );
            
            await ctx.reply(
                '🎓 *Welcome to Zone News Bot Tutorial!*\n\n' +
                'I\'ll guide you through everything step by step.\n\n' +
                '*Step 1: Understanding the Basics*\n\n' +
                'Zone News Bot helps you:\n' +
                '• 📰 Aggregate news content\n' +
                '• 📤 Post to multiple platforms\n' +
                '• ⏰ Schedule content\n' +
                '• 💰 Earn through affiliates\n\n' +
                'Ready to continue?',
                {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: 'Continue →', callback_data: 'onboard:tutorial:2' }],
                            [{ text: 'Skip Tutorial', callback_data: 'onboard:skip' }]
                        ]
                    }
                }
            );
        } catch (error) {
            console.error('Error in tutorial:', error);
            await ctx.reply('❌ Error starting tutorial.');
        }
    }

    /**
     * Handle callback actions
     */
    async handleAboutCallback(ctx) {
        try {
            const action = ctx.callbackQuery.data.split(':')[1];
            
            switch (action) {
                case 'demo':
                    await ctx.answerCallbackQuery();
                    await this.handleDemo(ctx);
                    break;
                    
                case 'docs':
                    await ctx.answerCallbackQuery('Opening documentation...');
                    await ctx.reply(
                        '📚 *Documentation*\n\n' +
                        '*Quick Links:*\n' +
                        '• [Getting Started](https://docs.zonenews.com/start)\n' +
                        '• [API Reference](https://docs.zonenews.com/api)\n' +
                        '• [FAQ](https://docs.zonenews.com/faq)\n' +
                        '• [Video Tutorials](https://youtube.com/@zonenews)\n\n' +
                        '_Documentation is being updated regularly._',
                        { 
                            parse_mode: 'Markdown',
                            disable_web_page_preview: true
                        }
                    );
                    break;
                    
                default:
                    await ctx.answerCallbackQuery();
            }
        } catch (error) {
            console.error('Error in about callback:', error);
            await ctx.answerCallbackQuery('Error');
        }
    }

    /**
     * Handle groups callbacks
     */
    async handleGroupsCallback(ctx) {
        try {
            const action = ctx.callbackQuery.data.split(':')[1];
            
            switch (action) {
                case 'howto':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '➕ *How to Add Bot to Your Group*\n\n' +
                        '1️⃣ Open your group\n' +
                        '2️⃣ Tap group name at top\n' +
                        '3️⃣ Tap "Add Members"\n' +
                        '4️⃣ Search: @ZoneNewsBot\n' +
                        '5️⃣ Add the bot\n\n' +
                        '*For Admin Features:*\n' +
                        '6️⃣ Make bot admin (optional)\n' +
                        '7️⃣ Grant posting permissions\n\n' +
                        'The bot will auto-detect when added! ✅',
                        { parse_mode: 'Markdown' }
                    );
                    break;
                    
                case 'discover':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '🔍 *Discover Groups*\n\n' +
                        '*Adelaide & SA Groups:*\n\n' +
                        '📰 News & Media\n' +
                        '• @AdelaideNewsGroup\n' +
                        '• @SAMediaWatch\n\n' +
                        '🏛️ Politics & Gov\n' +
                        '• @SAPoliticsDiscussion\n' +
                        '• @AdelaideCouncilWatch\n\n' +
                        '💼 Business\n' +
                        '• @AdelaideStartups\n' +
                        '• @SABusinessNetwork\n\n' +
                        '🎭 Lifestyle\n' +
                        '• @AdelaideEvents\n' +
                        '• @SAFoodieGroup\n\n' +
                        '_Join these groups to stay connected!_',
                        { parse_mode: 'Markdown' }
                    );
                    break;
                    
                case 'stats':
                    await ctx.answerCallbackQuery();
                    const stats = await this.getGroupStats(ctx.from.id);
                    await ctx.reply(
                        '📊 *Your Group Statistics*\n\n' +
                        `Groups Managed: ${stats.groupCount}\n` +
                        `Posts This Week: ${stats.weeklyPosts}\n` +
                        `Total Reach: ${stats.totalReach}\n` +
                        `Engagement Rate: ${stats.engagementRate}%\n\n` +
                        '_Upgrade to Pro for detailed analytics_',
                        { parse_mode: 'Markdown' }
                    );
                    break;
                    
                default:
                    await ctx.answerCallbackQuery();
            }
        } catch (error) {
            console.error('Error in groups callback:', error);
            await ctx.answerCallbackQuery('Error');
        }
    }

    /**
     * Handle channels callbacks
     */
    async handleChannelsCallback(ctx) {
        try {
            const action = ctx.callbackQuery.data.split(':')[1];
            
            switch (action) {
                case 'howto':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '➕ *How to Add Bot to Your Channel*\n\n' +
                        '1️⃣ Open your channel\n' +
                        '2️⃣ Tap channel name\n' +
                        '3️⃣ Tap "Administrators"\n' +
                        '4️⃣ Tap "Add Administrator"\n' +
                        '5️⃣ Search: @ZoneNewsBot\n' +
                        '6️⃣ Add bot as admin\n\n' +
                        '*Required Permissions:*\n' +
                        '• ✅ Post messages\n' +
                        '• ✅ Edit messages\n' +
                        '• ✅ Delete messages (optional)\n\n' +
                        'Bot will auto-detect the channel! ✅',
                        { parse_mode: 'Markdown' }
                    );
                    break;
                    
                case 'tips':
                    await ctx.answerCallbackQuery();
                    await ctx.reply(
                        '📈 *Channel Growth Tips*\n\n' +
                        '1️⃣ *Consistent Posting*\n' +
                        'Post 3-5 times daily at peak hours\n\n' +
                        '2️⃣ *Quality Content*\n' +
                        'Mix news, analysis, and exclusive content\n\n' +
                        '3️⃣ *Engagement*\n' +
                        'Use polls, quizzes, and discussions\n\n' +
                        '4️⃣ *Cross-Promotion*\n' +
                        'Partner with related channels\n\n' +
                        '5️⃣ *SEO Optimization*\n' +
                        'Use relevant keywords and hashtags\n\n' +
                        '_Pro tip: Use our scheduler for consistent posting!_',
                        { parse_mode: 'Markdown' }
                    );
                    break;
                    
                case 'analytics':
                    const userTier = await this.tierManager.getUserTier(ctx.from.id);
                    if (userTier === 'free' || userTier === 'basic') {
                        await ctx.answerCallbackQuery();
                        await ctx.reply(
                            '📊 *Channel Analytics* is a Pro feature.\n\n' +
                            'Upgrade to Pro to get:\n' +
                            '• Detailed view statistics\n' +
                            '• Engagement metrics\n' +
                            '• Growth trends\n' +
                            '• Best posting times\n' +
                            '• Audience insights',
                            { 
                                parse_mode: 'Markdown',
                                reply_markup: {
                                    inline_keyboard: [
                                        [{ text: '💎 Upgrade to Pro', callback_data: 'subscribe:pro' }],
                                        [{ text: '« Back', callback_data: 'back:main' }]
                                    ]
                                }
                            }
                        );
                    } else {
                        await ctx.answerCallbackQuery('Loading analytics...');
                        // Show analytics for Pro users
                    }
                    break;
                    
                default:
                    await ctx.answerCallbackQuery();
            }
        } catch (error) {
            console.error('Error in channels callback:', error);
            await ctx.answerCallbackQuery('Error');
        }
    }

    /**
     * Handle onboarding callbacks
     */
    async handleOnboardCallback(ctx) {
        try {
            const parts = ctx.callbackQuery.data.split(':');
            const action = parts[1];
            
            switch (action) {
                case 'quickstart':
                    await ctx.answerCallbackQuery();
                    await this.showQuickStart(ctx);
                    break;
                    
                case 'demo':
                    const demoType = parts[2];
                    await ctx.answerCallbackQuery();
                    await this.showDemo(ctx, demoType);
                    break;
                    
                case 'tutorial':
                    const step = parseInt(parts[2]);
                    await ctx.answerCallbackQuery();
                    await this.showTutorialStep(ctx, step);
                    break;
                    
                case 'skip':
                    await ctx.answerCallbackQuery('Tutorial skipped');
                    await this.backToMain(ctx);
                    break;
                    
                default:
                    await ctx.answerCallbackQuery();
            }
        } catch (error) {
            console.error('Error in onboard callback:', error);
            await ctx.answerCallbackQuery('Error');
        }
    }

    /**
     * Show quick start guide
     */
    async showQuickStart(ctx) {
        await ctx.reply(
            '🚀 *Quick Start Guide*\n\n' +
            '*In 3 Simple Steps:*\n\n' +
            '1️⃣ *Add Bot to Your Group/Channel*\n' +
            'Just add @ZoneNewsBot as member/admin\n\n' +
            '2️⃣ *Create Your First Post*\n' +
            'Use /post to create content\n\n' +
            '3️⃣ *Schedule or Send*\n' +
            'Post immediately or schedule for later\n\n' +
            '*Try it now:*',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '📤 Create First Post', callback_data: 'post:start' }],
                        [{ text: '📹 Watch Video Guide', callback_data: 'onboard:video' }],
                        [{ text: '« Back', callback_data: 'back:main' }]
                    ]
                }
            }
        );
    }

    /**
     * Show demo based on type
     */
    async showDemo(ctx, type) {
        const demos = {
            post: {
                title: 'Posting Demo',
                content: 'Let me show you how to create and send posts...',
                action: 'Try creating a post with /post'
            },
            schedule: {
                title: 'Scheduling Demo',
                content: 'Schedule posts for optimal timing...',
                action: 'Try scheduling with /schedule'
            },
            media: {
                title: 'Media Demo',
                content: 'Send photos, videos, and documents...',
                action: 'Send me any media file to try'
            },
            template: {
                title: 'Templates Demo',
                content: 'Save time with reusable templates...',
                action: 'Create a template with /savetemplate'
            },
            earnings: {
                title: 'Earnings Demo',
                content: 'Earn 20.5% commission on referrals...',
                action: 'Check your earnings with /earnings'
            }
        };
        
        const demo = demos[type];
        if (demo) {
            await ctx.reply(
                `🎬 *${demo.title}*\n\n` +
                `${demo.content}\n\n` +
                `💡 ${demo.action}`,
                { parse_mode: 'Markdown' }
            );
        }
    }

    /**
     * Back to main menu
     */
    async backToMain(ctx) {
        try {
            // Trigger /start command to show main menu
            ctx.message = ctx.message || ctx.callbackQuery.message;
            ctx.message.text = '/start';
            ctx.message.from = ctx.from;
            
            // Find and execute start command
            const startCommand = this.bot.telegram.commands?.find(c => c.command === 'start');
            if (startCommand) {
                await startCommand.handler(ctx);
            } else {
                // Fallback: show basic menu
                await ctx.reply(
                    '🏠 *Main Menu*\n\n' +
                    'What would you like to do?',
                    {
                        parse_mode: 'Markdown',
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    { text: '📰 Latest News', callback_data: 'news:latest' },
                                    { text: '🌐 Mini App', callback_data: 'miniapp:open' }
                                ],
                                [
                                    { text: '📱 Groups', callback_data: 'groups:menu' },
                                    { text: '📢 Channels', callback_data: 'channels:menu' }
                                ],
                                [{ text: 'ℹ️ About', callback_data: 'about:menu' }]
                            ]
                        }
                    }
                );
            }
            
            await ctx.answerCallbackQuery();
        } catch (error) {
            console.error('Error going back to main:', error);
            await ctx.answerCallbackQuery('Error');
        }
    }

    /**
     * Get user statistics
     */
    async getUserStats(userId) {
        try {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            const [postsToday, totalPosts] = await Promise.all([
                this.db.collection('post_history').countDocuments({
                    user_id: userId,
                    created_at: { $gte: today }
                }),
                this.db.collection('post_history').countDocuments({
                    user_id: userId
                })
            ]);
            
            return { postsToday, totalPosts };
        } catch (error) {
            console.error('Error getting user stats:', error);
            return null;
        }
    }

    /**
     * Get group statistics
     */
    async getGroupStats(userId) {
        try {
            // Mock data for now - replace with real stats
            return {
                groupCount: 3,
                weeklyPosts: 21,
                totalReach: '1.2K',
                engagementRate: 4.5
            };
        } catch (error) {
            console.error('Error getting group stats:', error);
            return {
                groupCount: 0,
                weeklyPosts: 0,
                totalReach: '0',
                engagementRate: 0
            };
        }
    }
}

module.exports = OnboardingFlow;