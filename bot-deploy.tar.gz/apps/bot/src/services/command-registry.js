/**
 * Command Registry - Central command management
 */

const StartCommand = require('./commands/start-command');
const NewsCommand = require('./commands/news-command');
const PostCommand = require('./commands/post-command');
const SearchCommand = require('./commands/search-command');
const SettingsCommand = require('./commands/settings-command');
const HelpCommand = require('./commands/help-command');
const AdminCommand = require('./commands/admin-command');
const BroadcastCommand = require('./commands/broadcast-command');

class CommandRegistry {
    constructor(bot, db, services) {
        this.bot = bot;
        this.db = db;
        this.services = services;
        this.commands = new Map();
        
        this.initializeCommands();
    }
    
    initializeCommands() {
        // Initialize command handlers
        this.commands.set('start', new StartCommand(
            this.bot, 
            this.db, 
            this.services.setupWizard
        ));
        
        this.commands.set('news', new NewsCommand(
            this.bot,
            this.db,
            this.services.pagination,
            this.services.postManager
        ));
        
        this.commands.set('post', new PostCommand(
            this.bot,
            this.db,
            this.services.postManager
        ));
        
        this.commands.set('search', new SearchCommand(
            this.bot,
            this.db,
            this.services.pagination
        ));
        
        this.commands.set('settings', new SettingsCommand(
            this.bot,
            this.db
        ));
        
        this.commands.set('help', new HelpCommand(
            this.bot,
            this.db
        ));
        
        this.commands.set('admin', new AdminCommand(
            this.bot,
            this.db,
            this.services
        ));
        
        this.commands.set('broadcast', new BroadcastCommand(
            this.bot,
            this.db,
            this.services.security
        ));
    }
    
    /**
     * Register all commands with bot
     */
    async register() {
        // Register command handlers
        this.bot.command('start', ctx => this.handleCommand('start', ctx));
        this.bot.command('news', ctx => this.handleCommand('news', ctx));
        this.bot.command('search', ctx => this.handleCommand('search', ctx));
        this.bot.command('settings', ctx => this.handleCommand('settings', ctx));
        this.bot.command('help', ctx => this.handleCommand('help', ctx));
        this.bot.command('post', ctx => this.handleCommand('post', ctx));
        this.bot.command('admin', ctx => this.handleCommand('admin', ctx));
        this.bot.command('broadcast', ctx => this.handleCommand('broadcast', ctx));
        
        // Register additional commands
        this.bot.command('miniapp', ctx => this.handleMiniApp(ctx));
        this.bot.command('setup', ctx => this.handleSetup(ctx));
        this.bot.command('discover', ctx => this.handleDiscover(ctx));
        this.bot.command('stats', ctx => this.handleStats(ctx));
        this.bot.command('trending', ctx => this.handleTrending(ctx));
        
        // Register callback query handlers
        this.registerCallbackHandlers();
        
        // Set bot commands for menu
        await this.setBotCommands();
        
        console.log('✅ Commands registered');
    }
    
    /**
     * Handle command execution
     */
    async handleCommand(commandName, ctx) {
        try {
            const command = this.commands.get(commandName);
            if (!command) {
                return ctx.reply('❌ Command not found');
            }
            
            // Extract arguments
            const text = ctx.message.text;
            const args = text.split(' ').slice(1);
            
            // Check rate limit
            const userId = ctx.from.id;
            const rateLimit = this.services.security.checkRateLimit(userId);
            
            if (!rateLimit.allowed) {
                return ctx.reply(`⏱️ ${rateLimit.message}`);
            }
            
            // Execute command
            await command.handle(ctx, args);
            
            // Track usage
            await this.trackCommandUsage(userId, commandName);
            
        } catch (error) {
            console.error(`Command error (${commandName}):`, error);
            ctx.reply('❌ An error occurred. Please try again.').catch(() => {});
        }
    }
    
    /**
     * Register callback query handlers
     */
    registerCallbackHandlers() {
        // News callbacks
        this.bot.action(/^news:/, async ctx => {
            const action = ctx.callbackQuery.data.split(':')[1];
            const newsCommand = this.commands.get('news');
            
            switch (action) {
                case 'latest':
                case 'all':
                case 'refresh':
                    await newsCommand.handleRefresh(ctx);
                    break;
                case 'cat':
                    const category = ctx.callbackQuery.data.split(':')[2];
                    await newsCommand.handleCategoryFilter(ctx, category);
                    break;
                case 'page':
                    const page = parseInt(ctx.callbackQuery.data.split(':')[2]);
                    await newsCommand.handlePagination(ctx, page);
                    break;
            }
        });
        
        // Post callbacks
        this.bot.action(/^post:/, async ctx => {
            const parts = ctx.callbackQuery.data.split(':');
            const action = parts[1];
            const postCommand = this.commands.get('post');
            
            switch (action) {
                case 'article':
                    await postCommand.handleArticleSelection(ctx, parts[2]);
                    break;
                case 'dest':
                    await postCommand.handleDestinationSelection(ctx, parts[2]);
                    break;
                case 'cancel':
                    await postCommand.handleCancel(ctx);
                    break;
                case 'new':
                    await postCommand.handle(ctx);
                    break;
                case 'done':
                    await ctx.deleteMessage();
                    break;
            }
        });
        
        // Settings callbacks
        this.bot.action(/^settings:/, async ctx => {
            const settingsCommand = this.commands.get('settings');
            await settingsCommand.handleCallback(ctx);
        });
        
        // Setup wizard callbacks
        this.bot.action(/^wizard:/, async ctx => {
            const parts = ctx.callbackQuery.data.split(':');
            const action = parts[1];
            
            if (action === 'toggle_cat') {
                await this.services.setupWizard.toggleCategory(ctx, parts[2]);
            } else {
                await this.services.setupWizard.handleStep(ctx, action);
            }
        });
    }
    
    /**
     * Set bot commands in menu
     */
    async setBotCommands() {
        const commands = [
            { command: 'start', description: 'Start the bot' },
            { command: 'news', description: 'Get latest news' },
            { command: 'search', description: 'Search articles' },
            { command: 'settings', description: 'Configure preferences' },
            { command: 'miniapp', description: 'Open mini app' },
            { command: 'discover', description: 'Discover trending content' },
            { command: 'help', description: 'Show help message' }
        ];
        
        const adminCommands = [
            ...commands,
            { command: 'post', description: 'Post article to channels' },
            { command: 'broadcast', description: 'Send broadcast message' },
            { command: 'admin', description: 'Admin panel' },
            { command: 'stats', description: 'View bot statistics' }
        ];
        
        try {
            // Set default commands
            await this.bot.telegram.setMyCommands(commands);
            
            // Set admin commands for admin users
            const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
            for (const adminId of adminIds) {
                await this.bot.telegram.setMyCommands(adminCommands, {
                    scope: { type: 'chat', chat_id: adminId }
                });
            }
            
            console.log('✅ Bot commands set');
        } catch (error) {
            console.error('Failed to set bot commands:', error);
        }
    }
    
    /**
     * Handle mini app command
     */
    async handleMiniApp(ctx) {
        const miniAppUrl = process.env.MINI_APP_URL || 'https://thezonenews.com/miniapp';
        
        await ctx.reply(
            '📱 *Zone News Mini App*\n\n' +
            'Access the full web experience with:\n' +
            '• Rich article viewing\n' +
            '• Advanced search\n' +
            '• Category browsing\n' +
            '• Save articles\n' +
            '• Share content\n\n' +
            'Click the button below to open:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: [[{
                        text: '📱 Open Mini App',
                        web_app: { url: miniAppUrl }
                    }]]
                }
            }
        );
    }
    
    /**
     * Handle setup command
     */
    async handleSetup(ctx) {
        await this.services.setupWizard.startWizard(ctx);
    }
    
    /**
     * Handle discover command
     */
    async handleDiscover(ctx) {
        const trending = await this.db.collection('news_articles')
            .aggregate([
                {
                    $match: {
                        published_date: {
                            $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
                        }
                    }
                },
                {
                    $addFields: {
                        engagement_score: {
                            $add: [
                                { $ifNull: ['$total_reactions.like', 0] },
                                { $multiply: [{ $ifNull: ['$total_reactions.love', 0] }, 2] },
                                { $multiply: [{ $ifNull: ['$total_reactions.fire', 0] }, 3] }
                            ]
                        }
                    }
                },
                { $sort: { engagement_score: -1 } },
                { $limit: 5 }
            ])
            .toArray();
        
        if (trending.length === 0) {
            return ctx.reply('📊 No trending articles found. Check back later!');
        }
        
        const Formatter = require('./utils/formatter');
        let message = '🔥 *Trending This Week*\n\n';
        
        trending.forEach((article, i) => {
            const reactions = article.total_reactions || {};
            const total = (reactions.like || 0) + (reactions.love || 0) + (reactions.fire || 0);
            
            message += `${i + 1}. ${Formatter.formatArticle(article)}\n`;
            message += `   💬 ${total} reactions\n\n`;
        });
        
        await ctx.reply(message, {
            parse_mode: 'Markdown',
            disable_web_page_preview: true
        });
    }
    
    /**
     * Handle stats command
     */
    async handleStats(ctx) {
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(ctx.from.id)) {
            return ctx.reply('❌ Admin only command');
        }
        
        // Gather statistics
        const [
            userCount,
            articleCount,
            reactionCount,
            groupCount
        ] = await Promise.all([
            this.db.collection('users').countDocuments(),
            this.db.collection('news_articles').countDocuments(),
            this.db.collection('user_reactions').countDocuments(),
            this.db.collection('bot_groups').countDocuments({ active: true })
        ]);
        
        const stats = `
📊 *Bot Statistics*

👥 *Users:* ${userCount}
📰 *Articles:* ${articleCount}
💬 *Reactions:* ${reactionCount}
👔 *Groups:* ${groupCount}

⏰ *Uptime:* ${this.formatUptime(process.uptime())}
💾 *Memory:* ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB
        `;
        
        await ctx.reply(stats, { parse_mode: 'Markdown' });
    }
    
    /**
     * Handle trending command
     */
    async handleTrending(ctx) {
        await this.handleDiscover(ctx);
    }
    
    /**
     * Track command usage
     */
    async trackCommandUsage(userId, command) {
        await this.db.collection('command_usage').insertOne({
            user_id: userId,
            command,
            timestamp: new Date()
        });
    }
    
    /**
     * Format uptime
     */
    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        
        if (days > 0) {
            return `${days}d ${hours}h ${mins}m`;
        }
        return `${hours}h ${mins}m`;
    }
}

module.exports = CommandRegistry;