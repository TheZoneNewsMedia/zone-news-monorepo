/**
 * Admin Management Service
 * Handles multi-admin support with roles and permissions
 */

class AdminService {
    constructor(db) {
        this.db = db;
        
        // Owner account (cannot be removed)
        this.OWNER_ID = 8123893898;
        
        // Role permissions
        this.ROLE_PERMISSIONS = {
            owner: ['all'],
            moderator: ['post', 'manage_destinations', 'view_stats', 'schedule'],
            editor: ['post', 'view_stats'],
            viewer: ['view_stats']
        };
        
        // Cache admins in memory for performance
        this.adminCache = new Map();
        this.adminCache.set(this.OWNER_ID, {
            username: '@TheZoneNews',
            role: 'owner',
            permissions: this.ROLE_PERMISSIONS.owner
        });
    }
    
    async isAdmin(userId) {
        // Check cache first
        if (this.adminCache.has(userId)) {
            return true;
        }
        
        // Check database
        const dbAdmin = await this.db.collection('bot_admins').findOne({ 
            telegram_id: userId, 
            active: true 
        });
        
        if (dbAdmin) {
            // Update cache
            this.adminCache.set(userId, {
                username: dbAdmin.username,
                role: dbAdmin.role,
                permissions: dbAdmin.permissions
            });
            return true;
        }
        
        return false;
    }
    
    hasPermission(userId, permission) {
        const admin = this.adminCache.get(userId);
        if (!admin) return false;
        
        return admin.permissions.includes('all') || 
               admin.permissions.includes(permission);
    }
    
    async addAdmin(userId, username, role, addedBy) {
        // Prevent duplicate owner
        if (role === 'owner' && userId !== this.OWNER_ID) {
            throw new Error('Only one owner account allowed');
        }
        
        const permissions = this.ROLE_PERMISSIONS[role] || this.ROLE_PERMISSIONS.viewer;
        
        await this.db.collection('bot_admins').updateOne(
            { telegram_id: userId },
            {
                $set: {
                    telegram_id: userId,
                    username: username,
                    role: role,
                    permissions: permissions,
                    added_by: addedBy,
                    added_at: new Date(),
                    active: true
                }
            },
            { upsert: true }
        );
        
        // Update cache
        this.adminCache.set(userId, {
            username: username,
            role: role,
            permissions: permissions
        });
        
        return true;
    }
    
    async removeAdmin(userId, removedBy) {
        // Cannot remove owner
        if (userId === this.OWNER_ID) {
            throw new Error('Cannot remove owner account');
        }
        
        await this.db.collection('bot_admins').updateOne(
            { telegram_id: userId },
            { 
                $set: { 
                    active: false, 
                    removed_at: new Date(), 
                    removed_by: removedBy 
                } 
            }
        );
        
        // Remove from cache
        this.adminCache.delete(userId);
        
        return true;
    }
    
    async getAllAdmins() {
        const dbAdmins = await this.db.collection('bot_admins')
            .find({ active: true })
            .toArray();
        
        // Combine with owner
        const allAdmins = [
            { 
                telegram_id: this.OWNER_ID, 
                username: '@TheZoneNews', 
                role: 'owner',
                permissions: this.ROLE_PERMISSIONS.owner
            },
            ...dbAdmins
        ];
        
        return allAdmins;
    }
}

module.exports = AdminService;