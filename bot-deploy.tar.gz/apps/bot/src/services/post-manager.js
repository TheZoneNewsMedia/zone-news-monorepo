/**
 * Post Manager - Handles posting with reactions and editing
 */

const { ObjectId } = require('mongodb');

class PostManager {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
    }
    
    /**
     * Post article to destination with reactions
     */
    async postArticle(articleId, destinationId, adminId) {
        try {
            const article = await this.db.collection('news_articles')
                .findOne({ _id: new ObjectId(articleId) });
            
            const destination = await this.db.collection('destinations')
                .findOne({ _id: new ObjectId(destinationId) });
            
            if (!article || !destination) {
                throw new Error('Article or destination not found');
            }
            
            // Pre-check permissions for groups
            if (destination.type === 'group' || destination.type === 'supergroup') {
                const perms = await this.checkGroupPermissions(destination.id);
                
                if (!perms.hasPermissions) {
                    // Try to provide helpful error message
                    if (perms.error?.includes('kicked')) {
                        // Mark destination as inactive
                        await this.db.collection('destinations').updateOne(
                            { _id: new ObjectId(destinationId) },
                            { $set: { active: false, error: 'Bot was kicked', last_error: new Date() } }
                        );
                        throw new Error('Bot was kicked from this group. Destination marked as inactive.');
                    }
                    
                    if (!perms.permissions?.canPost) {
                        throw new Error(
                            `Missing permissions in group "${destination.name || destination.id}":\n` +
                            `• Admin status: ${perms.permissions?.isAdmin ? '✅' : '❌'}\n` +
                            `• Can post: ${perms.permissions?.canPost ? '✅' : '❌'}\n` +
                            `• Status: ${perms.status}\n\n` +
                            `Please make the bot an admin with "Post messages" permission.`
                        );
                    }
                    
                    throw new Error(`Cannot post to group: ${perms.error || 'Unknown permission issue'}`);
                }
            }
            
            // Format message
            const message = this.formatArticleWithReactions(article);
            
            // Create inline keyboard with reactions
            const keyboard = this.createReactionKeyboard(article);
            
            // Send message with retry logic
            let sentMessage;
            let retries = 3;
            let lastError;
            
            while (retries > 0) {
                try {
                    sentMessage = await this.bot.telegram.sendMessage(
                        destination.id,
                        message,
                        {
                            parse_mode: 'Markdown',
                            reply_markup: keyboard,
                            disable_web_page_preview: false
                        }
                    );
                    break; // Success!
                    
                } catch (error) {
                    lastError = error;
                    retries--;
                    
                    // Handle specific errors
                    if (error.response?.error_code === 429) {
                        // Rate limited - wait and retry
                        const retryAfter = error.response?.parameters?.retry_after || 5;
                        console.log(`Rate limited. Waiting ${retryAfter} seconds...`);
                        await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
                        continue;
                    }
                    
                    // Handle permission errors
                    if (error.description?.includes('not enough rights')) {
                        throw new Error(
                            'Bot needs admin rights in the group to post.\n' +
                            'Please:\n' +
                            '1. Make the bot an admin\n' +
                            '2. Enable "Post messages" permission\n' +
                            '3. Try posting again'
                        );
                    }
                    
                    if (error.description?.includes('chat not found')) {
                        await this.db.collection('destinations').updateOne(
                            { _id: new ObjectId(destinationId) },
                            { $set: { active: false, error: 'Chat not found', last_error: new Date() } }
                        );
                        throw new Error('Chat not found. Bot may have been removed. Destination deactivated.');
                    }
                    
                    if (error.description?.includes('bot was kicked')) {
                        await this.db.collection('destinations').updateOne(
                            { _id: new ObjectId(destinationId) },
                            { $set: { active: false, error: 'Bot was kicked', last_error: new Date() } }
                        );
                        throw new Error('Bot was kicked from the group. Destination deactivated.');
                    }
                    
                    if (error.description?.includes('CHAT_WRITE_FORBIDDEN')) {
                        throw new Error(
                            'Bot cannot write to this chat.\n' +
                            'Possible reasons:\n' +
                            '• Bot is not a member\n' +
                            '• Chat has restricted who can post\n' +
                            '• Bot lacks necessary permissions'
                        );
                    }
                    
                    if (error.description?.includes('message is too long')) {
                        // Truncate and retry
                        const truncatedMessage = message.substring(0, 4000) + '...\n\n[Message truncated]';
                        sentMessage = await this.bot.telegram.sendMessage(
                            destination.id,
                            truncatedMessage,
                            {
                                parse_mode: 'Markdown',
                                reply_markup: keyboard,
                                disable_web_page_preview: false
                            }
                        );
                        break;
                    }
                    
                    // If no retries left, throw the error
                    if (retries === 0) {
                        throw error;
                    }
                    
                    // Wait before retry
                    await new Promise(resolve => setTimeout(resolve, 1000));
                }
            }
            
            if (!sentMessage && lastError) {
                throw lastError;
            }
            
            // Store posted article info for editing later
            await this.db.collection('posted_articles').insertOne({
                article_id: new ObjectId(articleId),
                destination_id: new ObjectId(destinationId),
                destination_chat_id: destination.id,
                message_id: sentMessage.message_id,
                posted_by: adminId,
                posted_at: new Date(),
                can_edit_until: new Date(Date.now() + 48 * 60 * 60 * 1000), // 48 hours
                reactions: {
                    like: 0,
                    love: 0,
                    fire: 0
                }
            });
            
            return {
                success: true,
                message_id: sentMessage.message_id,
                destination: destination.name || destination.id
            };
        } catch (error) {
            console.error('Post article error:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Edit posted article
     */
    async editPostedArticle(postId, newText) {
        try {
            const post = await this.db.collection('posted_articles')
                .findOne({ _id: new ObjectId(postId) });
            
            if (!post) {
                throw new Error('Posted article not found');
            }
            
            // Check if still editable (48 hour limit)
            if (new Date() > new Date(post.can_edit_until)) {
                throw new Error('Cannot edit posts older than 48 hours');
            }
            
            // Get current reactions to preserve them
            const keyboard = await this.getUpdatedReactionKeyboard(post.article_id, post._id);
            
            // Edit the message
            await this.bot.telegram.editMessageText(
                post.destination_chat_id,
                post.message_id,
                null,
                newText,
                {
                    parse_mode: 'Markdown',
                    reply_markup: keyboard,
                    disable_web_page_preview: false
                }
            );
            
            // Update database
            await this.db.collection('posted_articles').updateOne(
                { _id: new ObjectId(postId) },
                { 
                    $set: { 
                        last_edited: new Date(),
                        edited_text: newText
                    }
                }
            );
            
            return { success: true };
        } catch (error) {
            console.error('Edit post error:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    
    /**
     * Update reaction count - tracks globally across all groups/channels
     */
    async updateReaction(ctx, reactionType, articleId, postId) {
        try {
            const userId = ctx.from.id;
            const chatId = ctx.chat.id;
            const chatType = ctx.chat.type; // 'private', 'group', 'supergroup', 'channel'
            
            // Track reaction globally for this user
            const existingReaction = await this.db.collection('user_reactions').findOne({
                user_id: userId,
                post_id: postId,
                reaction: reactionType
            });
            
            // Also track in global reactions collection for analytics
            const globalReactionKey = `${userId}_${articleId}_${reactionType}`;
            const existingGlobalReaction = await this.db.collection('global_reactions').findOne({
                user_id: userId,
                article_id: new ObjectId(articleId),
                reaction_type: reactionType
            });
            
            let newCount;
            if (existingReaction) {
                // Remove reaction
                await this.db.collection('user_reactions').deleteOne({
                    user_id: userId,
                    post_id: postId,
                    reaction: reactionType
                });
                
                // Decrement count in posted article
                await this.db.collection('posted_articles').updateOne(
                    { _id: new ObjectId(postId) },
                    { $inc: { [`reactions.${reactionType}`]: -1 } }
                );
                
                // Update global reaction tracking
                await this.db.collection('global_reactions').deleteOne({
                    user_id: userId,
                    article_id: new ObjectId(articleId),
                    reaction_type: reactionType
                });
                
                // Update article's total reaction count
                await this.db.collection('news_articles').updateOne(
                    { _id: new ObjectId(articleId) },
                    { $inc: { [`total_reactions.${reactionType}`]: -1 } }
                );
                
                newCount = -1;
            } else {
                // Add reaction with full tracking info
                await this.db.collection('user_reactions').insertOne({
                    user_id: userId,
                    username: ctx.from.username || null,
                    post_id: postId,
                    article_id: new ObjectId(articleId),
                    reaction: reactionType,
                    chat_id: chatId,
                    chat_type: chatType,
                    chat_title: ctx.chat.title || null,
                    created_at: new Date()
                });
                
                // Add to global reactions (one reaction per user per article type)
                if (!existingGlobalReaction) {
                    await this.db.collection('global_reactions').insertOne({
                        user_id: userId,
                        username: ctx.from.username || null,
                        article_id: new ObjectId(articleId),
                        reaction_type: reactionType,
                        first_reacted_at: new Date(),
                        last_reacted_at: new Date(),
                        reaction_count: 1,
                        chats_reacted_in: [{
                            chat_id: chatId,
                            chat_type: chatType,
                            chat_title: ctx.chat.title || null,
                            reacted_at: new Date()
                        }]
                    });
                } else {
                    // Update existing global reaction
                    await this.db.collection('global_reactions').updateOne(
                        { 
                            user_id: userId,
                            article_id: new ObjectId(articleId),
                            reaction_type: reactionType
                        },
                        { 
                            $set: { last_reacted_at: new Date() },
                            $inc: { reaction_count: 1 },
                            $push: { 
                                chats_reacted_in: {
                                    chat_id: chatId,
                                    chat_type: chatType,
                                    chat_title: ctx.chat.title || null,
                                    reacted_at: new Date()
                                }
                            }
                        }
                    );
                }
                
                // Increment count in posted article
                await this.db.collection('posted_articles').updateOne(
                    { _id: new ObjectId(postId) },
                    { $inc: { [`reactions.${reactionType}`]: 1 } }
                );
                
                // Update article's total reaction count
                await this.db.collection('news_articles').updateOne(
                    { _id: new ObjectId(articleId) },
                    { 
                        $inc: { [`total_reactions.${reactionType}`]: 1 },
                        $set: { last_reaction_at: new Date() }
                    }
                );
                
                newCount = 1;
            }
            
            // Get updated post with reactions
            const post = await this.db.collection('posted_articles')
                .findOne({ _id: new ObjectId(postId) });
            
            // Update the message keyboard with new counts
            const keyboard = await this.getUpdatedReactionKeyboard(articleId, postId);
            
            try {
                await ctx.editMessageReplyMarkup(keyboard);
            } catch (error) {
                // Message not modified error is ok
                if (!error.description?.includes('message is not modified')) {
                    console.error('Failed to update keyboard:', error);
                }
            }
            
            // Show feedback
            if (existingReaction) {
                await ctx.answerCbQuery('Reaction removed');
            } else {
                const emoji = reactionType === 'like' ? '👍' : reactionType === 'love' ? '❤️' : '🔥';
                await ctx.answerCbQuery(`${emoji} Added!`);
            }
            
            return { success: true, newCount };
        } catch (error) {
            console.error('Update reaction error:', error);
            await ctx.answerCbQuery('Failed to update reaction', { show_alert: true });
            return { success: false };
        }
    }
    
    /**
     * Format article with reactions support
     */
    formatArticleWithReactions(article) {
        const date = new Date(article.published_date).toLocaleDateString('en-AU');
        
        return `📰 *${this.escapeMarkdown(article.title)}*\n\n` +
            `${this.escapeMarkdown(article.summary || article.content?.substring(0, 300))}...\n\n` +
            `📅 ${date} | 📂 ${article.category || 'General'}\n` +
            `🔗 [Read More](${article.url || 'https://thezonenews.com'})`;
    }
    
    /**
     * Create reaction keyboard
     */
    createReactionKeyboard(article) {
        return {
            inline_keyboard: [
                [
                    { text: '👍 0', callback_data: `react:like:${article._id}` },
                    { text: '❤️ 0', callback_data: `react:love:${article._id}` },
                    { text: '🔥 0', callback_data: `react:fire:${article._id}` }
                ],
                [
                    { text: '💬 Comment', callback_data: `comment:${article._id}` },
                    { text: '🔗 Share', callback_data: `share:${article._id}` }
                ]
            ]
        };
    }
    
    /**
     * Get updated reaction keyboard with current counts
     */
    async getUpdatedReactionKeyboard(articleId, postId) {
        const post = await this.db.collection('posted_articles')
            .findOne({ _id: new ObjectId(postId) });
        
        const reactions = post?.reactions || { like: 0, love: 0, fire: 0 };
        
        return {
            inline_keyboard: [
                [
                    { text: `👍 ${reactions.like}`, callback_data: `react:like:${articleId}:${postId}` },
                    { text: `❤️ ${reactions.love}`, callback_data: `react:love:${articleId}:${postId}` },
                    { text: `🔥 ${reactions.fire}`, callback_data: `react:fire:${articleId}:${postId}` }
                ],
                [
                    { text: '💬 Comment', callback_data: `comment:${articleId}` },
                    { text: '🔗 Share', callback_data: `share:${articleId}` }
                ]
            ]
        };
    }
    
    /**
     * Escape markdown
     */
    escapeMarkdown(text) {
        if (!text) return '';
        return text.replace(/([_*[\]()~`>#+\-=|{}.!])/g, '\\$1');
    }
    
    /**
     * Check group permissions
     */
    async checkGroupPermissions(groupId) {
        try {
            const botMember = await this.bot.telegram.getChatMember(groupId, this.bot.botInfo.id);
            
            const permissions = {
                isAdmin: botMember.status === 'administrator',
                canPost: botMember.can_post_messages !== false,
                canEdit: botMember.can_edit_messages !== false,
                canDelete: botMember.can_delete_messages !== false,
                canPin: botMember.can_pin_messages !== false
            };
            
            return {
                hasPermissions: permissions.isAdmin || permissions.canPost,
                permissions,
                status: botMember.status
            };
        } catch (error) {
            return {
                hasPermissions: false,
                error: error.message
            };
        }
    }
    
    /**
     * Get reaction analytics for an article
     */
    async getReactionAnalytics(articleId) {
        try {
            // Get total reactions from article
            const article = await this.db.collection('news_articles')
                .findOne({ _id: new ObjectId(articleId) });
                
            const totalReactions = article?.total_reactions || { like: 0, love: 0, fire: 0 };
            
            // Get all posts of this article
            const posts = await this.db.collection('posted_articles')
                .find({ article_id: new ObjectId(articleId) })
                .toArray();
            
            // Get unique users who reacted
            const uniqueUsers = await this.db.collection('global_reactions')
                .distinct('user_id', { article_id: new ObjectId(articleId) });
            
            // Get reaction distribution by chat type
            const reactionsByChat = await this.db.collection('user_reactions')
                .aggregate([
                    { $match: { article_id: new ObjectId(articleId) } },
                    { $group: {
                        _id: { chat_type: '$chat_type', reaction: '$reaction' },
                        count: { $sum: 1 }
                    }}
                ])
                .toArray();
            
            // Get top reacting users
            const topReactors = await this.db.collection('global_reactions')
                .aggregate([
                    { $match: { article_id: new ObjectId(articleId) } },
                    { $group: {
                        _id: '$user_id',
                        username: { $first: '$username' },
                        total_reactions: { $sum: '$reaction_count' }
                    }},
                    { $sort: { total_reactions: -1 } },
                    { $limit: 10 }
                ])
                .toArray();
            
            return {
                article_id: articleId,
                article_title: article?.title,
                total_reactions: totalReactions,
                unique_reactors: uniqueUsers.length,
                posts_count: posts.length,
                reaction_distribution: reactionsByChat,
                top_reactors: topReactors,
                last_reaction_at: article?.last_reaction_at
            };
        } catch (error) {
            console.error('Get reaction analytics error:', error);
            return null;
        }
    }
    
    /**
     * Get user reaction history
     */
    async getUserReactionHistory(userId, limit = 50) {
        try {
            const reactions = await this.db.collection('user_reactions')
                .find({ user_id: userId })
                .sort({ created_at: -1 })
                .limit(limit)
                .toArray();
            
            // Get article details for each reaction
            const articleIds = [...new Set(reactions.map(r => r.article_id.toString()))];
            const articles = await this.db.collection('news_articles')
                .find({ _id: { $in: articleIds.map(id => new ObjectId(id)) } })
                .toArray();
            
            const articleMap = {};
            articles.forEach(a => {
                articleMap[a._id.toString()] = a;
            });
            
            return reactions.map(r => ({
                ...r,
                article: articleMap[r.article_id.toString()]
            }));
        } catch (error) {
            console.error('Get user reaction history error:', error);
            return [];
        }
    }
}

module.exports = PostManager;