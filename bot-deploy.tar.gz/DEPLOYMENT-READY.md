# 🚀 Zone News Monorepo - Deployment Ready

## Status: READY FOR SERVER DEPLOYMENT
Date: 2025-08-13

---

## ✅ Completed Components

### 1. Monorepo Structure (100%)
- ✅ pnpm workspaces configured
- ✅ Turborepo build pipeline
- ✅ TypeScript configuration
- ✅ Shared libraries setup

### 2. Shared Libraries (100%)
- ✅ **@zone/shared** - Types, constants, utils
- ✅ **@zone/database** - Models, repositories
- ✅ **@zone/cache** - Redis caching
- ✅ **@zone/auth** - Authentication
- ✅ **@zone/logger** - Logging

### 3. Applications

#### Bot App (@zone/bot) - 70%
- ✅ Package structure
- ✅ Migrated zone-bot-service.js
- ⚠️ Needs TypeScript conversion
- ⚠️ Needs testing

#### API App (@zone/api) - 80% (ChatGPT)
- ✅ Express server setup
- ✅ Multiple route handlers
- ✅ Auth middleware
- ⚠️ Needs database integration

#### Web App (@zone/web) - 100%
- ✅ Astro framework
- ✅ Homepage with components
- ✅ Tailwind CSS
- ✅ Responsive design
- ✅ Local news focus (not Adelaide-specific)

#### Mini App (@zone/miniapp) - 100%
- ✅ React + TypeScript
- ✅ Telegram WebApp SDK integration
- ✅ Tier-based access control
- ✅ News feed with limits
- ✅ Article viewer
- ✅ Profile management
- ✅ Animations with Framer Motion
- ✅ State management with Zustand

---

## 🚢 Deployment Instructions

### 1. Run Deployment Script
```bash
cd /Users/georgesimbe/telegramNewsBot/zone-news-monorepo
./scripts/deploy-to-server.sh
```

### 2. SSH to Server
```bash
ssh -i ~/telegramNewsBot/terraform/zone_news_private_key root@67.219.107.230
```

### 3. On Server - Install & Build
```bash
cd /root/zone-news-monorepo
pnpm install
pnpm build
```

### 4. Start Services with PM2
```bash
# Stop old services
pm2 delete all

# Start new monorepo services
pm2 start ecosystem.config.js
pm2 save
pm2 startup
```

### 5. Configure Nginx
```bash
# For Mini App
cat > /etc/nginx/sites-available/miniapp << 'EOF'
server {
    listen 80;
    server_name miniapp.thezonenews.com;
    
    location / {
        proxy_pass http://localhost:3003;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

ln -sf /etc/nginx/sites-available/miniapp /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

---

## 🔌 Service Endpoints

### Production URLs
- Bot Webhook: `https://bot.thezonenews.com/webhook`
- API: `http://67.219.107.230:3001`
- Mini App: `http://miniapp.thezonenews.com` (after nginx config)
- Web App: `http://67.219.107.230:3000`

### Telegram Integration
- Bot: @ZoneNewsBot
- Mini App: Set via BotFather to miniapp URL

---

## 📊 Tier System

| Tier | Price | Articles/Day | Features |
|------|-------|--------------|----------|
| Free | $0 | 10 | Mini app access, basic features |
| Pro | $14.99 | 50 | AI summaries, 1 channel, early access |
| Business | $29.99 | 200 | 5 channels, API access, analytics |
| Enterprise | $99.99 | Unlimited | Everything unlimited, white label |

---

## ⚠️ Important Notes

1. **Database**: MongoDB must be running on server (localhost:27017)
2. **Redis**: Redis should be running for caching (localhost:6379)
3. **Environment Variables**: Update tokens and secrets in ecosystem.config.js
4. **SSL**: Consider setting up Let's Encrypt for HTTPS
5. **Domain**: Update DNS for miniapp.thezonenews.com

---

## 📝 Testing Checklist

After deployment:
- [ ] Test bot commands (/start, /help, /mytier)
- [ ] Test API endpoints (GET /api/news)
- [ ] Test Mini App in Telegram
- [ ] Test Web App loading
- [ ] Check PM2 logs for errors
- [ ] Verify MongoDB connections
- [ ] Test tier limitations

---

## 🔧 Troubleshooting

### If services fail to start:
```bash
pm2 logs
pm2 restart all
```

### If MongoDB connection fails:
```bash
systemctl status mongod
systemctl restart mongod
```

### If Nginx fails:
```bash
nginx -t
systemctl restart nginx
```

---

## 📞 Support

- Server IP: 67.219.107.230
- SSH Key: ~/telegramNewsBot/terraform/zone_news_private_key
- MongoDB: mongodb://localhost:27017/zone_news_production

---

**Status**: Ready for production deployment
**Last Updated**: 2025-08-13 11:10
**Updated By**: Claude