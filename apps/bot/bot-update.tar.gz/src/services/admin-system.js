/**
 * Admin System - Handles admin-only functionality
 * Hidden from regular users
 */

const { Markup } = require('telegraf');

class AdminSystem {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
        
        // Core admin IDs
        this.coreAdmins = [
            7802629063,  // @DukeExxotic
            8123893898   // @TheZoneNews
        ];
        
        // Admin state management
        this.adminSessions = new Map();
    }
    
    /**
     * Check if user is admin
     */
    async isAdmin(userId) {
        // Check core admins first
        if (this.coreAdmins.includes(parseInt(userId))) {
            return true;
        }
        
        // Check database for additional admins
        const admin = await this.db.collection('admins').findOne({ 
            userId: parseInt(userId),
            active: true 
        });
        
        return !!admin;
    }
    
    /**
     * Register admin handlers
     */
    registerHandlers() {
        // Admin command
        this.bot.command('admin', async (ctx) => {
            const userId = ctx.from.id;
            if (!await this.isAdmin(userId)) {
                return; // Silent fail for non-admins
            }
            return this.showAdminPanel(ctx);
        });
        
        // Admin callbacks
        this.bot.action(/^admin_/, async (ctx) => {
            const userId = ctx.from.id;
            if (!await this.isAdmin(userId)) {
                return ctx.answerCbQuery('❌ Access denied', { show_alert: true });
            }
            return this.handleAdminAction(ctx);
        });
    }
    
    /**
     * Show admin panel
     */
    async showAdminPanel(ctx) {
        const stats = await this.getSystemStats();
        
        const message = 
            '👑 *Administrator Panel*\n\n' +
            '*System Overview:*\n' +
            `• Total Users: ${stats.totalUsers}\n` +
            `• Active Users (7d): ${stats.activeUsers}\n` +
            `• Total Posts: ${stats.totalPosts}\n` +
            `• Channels: ${stats.totalChannels}\n` +
            `• Groups: ${stats.totalGroups}\n\n` +
            '*Quick Actions:*';
        
        const keyboard = Markup.inlineKeyboard([
            [
                Markup.button.callback('👥 User Management', 'admin_users'),
                Markup.button.callback('📊 Statistics', 'admin_stats')
            ],
            [
                Markup.button.callback('📢 Broadcast', 'admin_broadcast'),
                Markup.button.callback('🔧 System', 'admin_system')
            ],
            [
                Markup.button.callback('📋 View Logs', 'admin_logs'),
                Markup.button.callback('💰 Revenue', 'admin_revenue')
            ],
            [
                Markup.button.callback('🎁 Grant Access', 'admin_grant'),
                Markup.button.callback('🚫 Ban User', 'admin_ban')
            ],
            [
                Markup.button.callback('🔄 Refresh', 'admin_panel'),
                Markup.button.callback('✖️ Close', 'close')
            ]
        ]);
        
        if (ctx.callbackQuery) {
            await ctx.editMessageText(message, {
                parse_mode: 'Markdown',
                ...keyboard
            });
            await ctx.answerCbQuery();
        } else {
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                ...keyboard
            });
        }
    }
    
    /**
     * Handle admin actions
     */
    async handleAdminAction(ctx) {
        const action = ctx.callbackQuery.data.replace('admin_', '');
        
        switch (action) {
            case 'panel':
                return this.showAdminPanel(ctx);
                
            case 'users':
                return this.showUserManagement(ctx);
                
            case 'stats':
                return this.showStatistics(ctx);
                
            case 'broadcast':
                return this.startBroadcast(ctx);
                
            case 'system':
                return this.showSystemInfo(ctx);
                
            case 'logs':
                return this.showLogs(ctx);
                
            case 'revenue':
                return this.showRevenue(ctx);
                
            case 'grant':
                return this.startGrantAccess(ctx);
                
            case 'ban':
                return this.startBanUser(ctx);
                
            default:
                if (action.startsWith('confirm_')) {
                    return this.handleConfirmation(ctx, action);
                }
                return ctx.answerCbQuery('🚧 Feature coming soon');
        }
    }
    
    /**
     * Show user management
     */
    async showUserManagement(ctx) {
        const users = await this.db.collection('users')
            .find({})
            .sort({ lastActive: -1 })
            .limit(10)
            .toArray();
        
        let message = '👥 *User Management*\n\n';
        message += '*Recent Active Users:*\n';
        
        users.forEach((user, index) => {
            const tier = user.tier || 'basic';
            const username = user.username ? `@${user.username}` : user.firstName || 'Unknown';
            message += `${index + 1}. ${username} (${tier})\n`;
        });
        
        const keyboard = Markup.inlineKeyboard([
            [
                Markup.button.callback('🔍 Search User', 'admin_search_user'),
                Markup.button.callback('📊 User Stats', 'admin_user_stats')
            ],
            [
                Markup.button.callback('🎁 Grant Premium', 'admin_grant_premium'),
                Markup.button.callback('🚫 Ban List', 'admin_ban_list')
            ],
            [
                Markup.button.callback('🔙 Back', 'admin_panel'),
                Markup.button.callback('✖️ Close', 'close')
            ]
        ]);
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    }
    
    /**
     * Show statistics
     */
    async showStatistics(ctx) {
        const now = new Date();
        const dayAgo = new Date(now - 24 * 60 * 60 * 1000);
        const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
        
        const [daily, weekly, monthly] = await Promise.all([
            this.getStatsForPeriod(dayAgo),
            this.getStatsForPeriod(weekAgo),
            this.getStatsForPeriod(new Date(now - 30 * 24 * 60 * 60 * 1000))
        ]);
        
        const message = 
            '📊 *System Statistics*\n\n' +
            '*Daily Stats:*\n' +
            `• New Users: ${daily.newUsers}\n` +
            `• Posts Created: ${daily.posts}\n` +
            `• Commands Used: ${daily.commands}\n\n` +
            '*Weekly Stats:*\n' +
            `• New Users: ${weekly.newUsers}\n` +
            `• Posts Created: ${weekly.posts}\n` +
            `• Commands Used: ${weekly.commands}\n\n` +
            '*Monthly Stats:*\n' +
            `• New Users: ${monthly.newUsers}\n` +
            `• Posts Created: ${monthly.posts}\n` +
            `• Commands Used: ${monthly.commands}`;
        
        const keyboard = Markup.inlineKeyboard([
            [
                Markup.button.callback('📈 Growth', 'admin_growth'),
                Markup.button.callback('💰 Revenue', 'admin_revenue')
            ],
            [
                Markup.button.callback('🔄 Refresh', 'admin_stats'),
                Markup.button.callback('📥 Export', 'admin_export_stats')
            ],
            [
                Markup.button.callback('🔙 Back', 'admin_panel'),
                Markup.button.callback('✖️ Close', 'close')
            ]
        ]);
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            ...keyboard
        });
        await ctx.answerCbQuery();
    }
    
    /**
     * Get system stats
     */
    async getSystemStats() {
        const [totalUsers, activeUsers, totalPosts, totalChannels, totalGroups] = await Promise.all([
            this.db.collection('users').countDocuments(),
            this.db.collection('users').countDocuments({
                lastActive: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
            }),
            this.db.collection('posts').countDocuments(),
            this.db.collection('destinations').countDocuments({ type: 'channel' }),
            this.db.collection('destinations').countDocuments({ type: { $in: ['group', 'supergroup'] } })
        ]);
        
        return {
            totalUsers,
            activeUsers,
            totalPosts,
            totalChannels,
            totalGroups
        };
    }
    
    /**
     * Get stats for a specific period
     */
    async getStatsForPeriod(since) {
        const [newUsers, posts, commands] = await Promise.all([
            this.db.collection('users').countDocuments({
                createdAt: { $gte: since }
            }),
            this.db.collection('posts').countDocuments({
                created_at: { $gte: since }
            }),
            this.db.collection('command_logs').countDocuments({
                timestamp: { $gte: since }
            })
        ]);
        
        return { newUsers, posts, commands };
    }
}

module.exports = AdminSystem;