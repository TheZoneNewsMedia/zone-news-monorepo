/**
 * Command Registry - Central command management
 */

// Available command files
const PostCommands = require('../commands/post-commands');
const TbcNightNews = require('../commands/tbc-night-news');

// TODO: Add these when command files are created
// const StartCommand = require('./commands/start-command');
// const NewsCommand = require('./commands/news-command');
// const SearchCommand = require('./commands/search-command');
// const SettingsCommand = require('./commands/settings-command');
// const HelpCommand = require('./commands/help-command');
// const AdminCommand = require('./commands/admin-command');
// const BroadcastCommand = require('./commands/broadcast-command');

class CommandRegistry {
    constructor(bot, db, services) {
        this.bot = bot;
        this.db = db;
        this.services = services;
        this.commands = new Map();
        
        this.initializeCommands();
    }
    
    initializeCommands() {
        // Set up basic commands directly since individual command files don't exist yet
        this.setupBasicCommands();
        console.log('✅ Basic command handlers initialized');
    }
    
    setupBasicCommands() {
        // Main /start command matching the professional interface
        this.bot.command('start', async (ctx) => {
            try {
                const userId = ctx.from.id;
                const username = ctx.from.username || ctx.from.first_name || 'User';
                
                // Update user stats
                if (this.services.stats) {
                    await this.services.stats.trackUser({
                        userId: userId,
                        username: username,
                        firstName: ctx.from.first_name,
                        lastName: ctx.from.last_name,
                        lastActive: new Date()
                    });
                }
                
                const welcomeMessage = `🎊 **Welcome to Zone News Bot!**

Your news hub for local and global updates, channel management, and more.

🎯 **What would you like to do?**`;
                
                const keyboard = {
                    inline_keyboard: [
                        [
                            { text: '📰 News', callback_data: 'news_menu' },
                            { text: '❓ About', callback_data: 'about_menu' }
                        ],
                        [
                            { text: '🎯 Features', callback_data: 'features_menu' },
                            { text: '📚 How to Use', callback_data: 'howto_menu' }
                        ],
                        [
                            { text: '📢 Channel Management', callback_data: 'channel_mgmt' },
                            { text: '👥 Group Management', callback_data: 'group_mgmt' }
                        ],
                        [
                            { text: '⚙️ Settings', callback_data: 'settings_menu' }
                        ]
                    ]
                };
                
                await ctx.reply(welcomeMessage, {
                    parse_mode: 'Markdown',
                    reply_markup: keyboard
                });
                
            } catch (error) {
                console.error('Start command error:', error);
                await ctx.reply('❌ Welcome! Something went wrong, but I\'m still here to help.');
            }
        });
        
        // Basic help command
        this.bot.command('help', async (ctx) => {
            const helpMessage = `🆘 **Zone News Adelaide Help**

**Available Commands:**
/start - Show main menu
/help - Show this help
/news - Latest news
/subscribe - Subscribe to updates

📞 **Support:** Contact @TheZoneNews for help`;
            
            await ctx.reply(helpMessage, { parse_mode: 'Markdown' });
        });
        
        // Basic news command
        this.bot.command('news', async (ctx) => {
            await ctx.reply('📰 News feature coming soon! Use the buttons in /start for now.');
        });
        
        // Initialize PostCommands if available
        try {
            this.postCommands = new PostCommands(this.bot, null, this.db);
            console.log('✅ Post commands initialized');
        } catch (error) {
            console.log('⚠️ PostCommands not available, using fallback');
            // Basic post command fallback
            this.bot.command('post', async (ctx) => {
                await ctx.reply('📝 Post feature coming soon! Contact admin for posting rights.');
            });
        }
    }
    
    /**
     * Handle callback queries from inline keyboards
     */
    async handleCallbackQuery(ctx) {
        const data = ctx.callbackQuery.data;
        
        try {
            switch (data) {
                case 'news_menu':
                    await ctx.answerCbQuery();
                    await ctx.reply('📰 **News Menu**\n\n• Latest breaking news\n• Category-based filtering\n• Search functionality\n• Subscription management\n\n🔜 Full news system launching soon!');
                    break;
                case 'about_menu':
                    await ctx.answerCbQuery();
                    await ctx.reply('❓ **About Zone News Bot**\n\n🎯 **Mission:** Your comprehensive news hub for local and global updates\n\n✨ **Features:**\n• Real-time news delivery\n• Channel management\n• Group administration\n• Custom notifications\n• Content scheduling\n\n👥 **Team:** @TheZoneNews');
                    break;
                case 'features_menu':
                    await ctx.answerCbQuery();
                    await ctx.reply('🎯 **Bot Features**\n\n📰 **News Management**\n• Auto-posting to channels\n• Content scheduling\n• Category filtering\n\n📢 **Channel Tools**\n• Bulk posting\n• Message templates\n• Analytics tracking\n\n👥 **Group Features**\n• Moderation tools\n• Welcome messages\n• Custom commands');
                    break;
                case 'howto_menu':
                    await ctx.answerCbQuery();
                    await ctx.reply('📚 **How to Use**\n\n1️⃣ **Setup:** /start to begin\n2️⃣ **Add Channel:** Use Channel Management\n3️⃣ **Configure:** Set preferences in Settings\n4️⃣ **Post Content:** Use /post command\n5️⃣ **Manage:** Track analytics and performance\n\n💡 **Tip:** Use /help anytime for assistance!');
                    break;
                case 'channel_mgmt':
                    await ctx.answerCbQuery();
                    await ctx.reply('📢 **Channel Management**\n\n🔧 **Available Commands:**\n• /addchannel - Add new channel\n• /channels - List all channels\n• /post - Post to channels\n• /schedule - Schedule posts\n• /analytics - View performance\n\n⚠️ **Note:** Bot must be admin in target channels');
                    break;
                case 'group_mgmt':
                    await ctx.answerCbQuery();
                    await ctx.reply('👥 **Group Management**\n\n🛡️ **Moderation Tools:**\n• Auto-moderation\n• Welcome messages\n• Custom rules\n• Member tracking\n\n🔜 Advanced group features coming soon!');
                    break;
                case 'settings_menu':
                    await ctx.answerCbQuery();
                    await ctx.reply('⚙️ **Settings**\n\n🔧 **Customize your experience:**\n• Notification preferences\n• Default posting format\n• Time zone settings\n• Language options\n\n💾 Settings are saved automatically');
                    break;
                default:
                    await ctx.answerCbQuery('Feature coming soon!');
            }
        } catch (error) {
            console.error('Callback query error:', error);
            try {
                await ctx.answerCbQuery('Something went wrong!');
            } catch (cbError) {
                console.error('Failed to answer callback query:', cbError);
            }
        }
    }

}

module.exports = CommandRegistry;
