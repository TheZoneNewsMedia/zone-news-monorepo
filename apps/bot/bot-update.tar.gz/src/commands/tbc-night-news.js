/**
 * TBC Night News Command
 * Posts night news to @ZoneNewsAdl and forwards to TBC
 */

const { Markup } = require('telegraf');

class TBCNightNewsCommand {
    constructor(bot, db) {
        this.bot = bot;
        this.db = db;
        
        // Configuration
        this.config = {
            sourceChannelId: -1002212113452, // @ZoneNewsAdl
            tbcGroupId: -2665614394,         // TBC group
            tbcTopicId: 9,                   // Zone News topic
            adminIds: process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [7802629063]
        };
        
        // Track messages for syncing
        this.messageMap = new Map();
    }

    /**
     * Register the command
     */
    register() {
        // Command to post night news
        this.bot.command('nightnews', async (ctx) => {
            // Check if admin
            if (!this.config.adminIds.includes(ctx.from?.id)) {
                return ctx.reply('❌ This command is restricted to admins only.');
            }
            
            await ctx.reply('📰 Starting Night News posting...');
            await this.postNightNews(ctx);
        });
        
        // Command to post single article
        this.bot.command('postarticle', async (ctx) => {
            if (!this.config.adminIds.includes(ctx.from?.id)) {
                return ctx.reply('❌ This command is restricted to admins only.');
            }
            
            const args = ctx.message.text.replace('/postarticle ', '');
            if (!args) {
                return ctx.reply('Usage: /postarticle <JSON article data>');
            }
            
            try {
                const article = JSON.parse(args);
                await this.postSingleArticle(article, ctx);
            } catch (error) {
                ctx.reply('❌ Invalid JSON format');
            }
        });
    }

    /**
     * Create reaction keyboard
     */
    createReactionKeyboard(messageId) {
        return Markup.inlineKeyboard([
            [
                Markup.button.callback('👍', `react:${messageId}:like`),
                Markup.button.callback('❤️', `react:${messageId}:love`),
                Markup.button.callback('🔥', `react:${messageId}:fire`),
                Markup.button.callback('🎉', `react:${messageId}:party`),
                Markup.button.callback('🤔', `react:${messageId}:think`),
                Markup.button.callback('😢', `react:${messageId}:sad`)
            ],
            [
                Markup.button.url('📤 Share', `https://t.me/ZoneNewsAdl/${messageId}`),
                Markup.button.callback('👁 Views', `views:${messageId}`)
            ]
        ]);
    }

    /**
     * Format article for posting
     */
    formatArticle(article) {
        let text = `<b>${article.title}</b>\n\n`;
        text += `${article.content}\n\n`;
        text += `<b>Category:</b> ${article.category}\n`;
        text += `<b>Source:</b> ${article.source}\n`;
        if (article.link) {
            text += `<b>Link:</b> <a href="${article.link}">Read more</a>`;
        }
        return text;
    }

    /**
     * Post night news articles
     */
    async postNightNews(ctx) {
        const articles = [
            {
                title: "OpenAI CEO admits AI bubble while planning trillion dollar bet",
                content: `OpenAI chief Sam Altman has conceded the artificial intelligence sector is caught in a speculative bubble, warning that "some three person start ups are fetching dot com era valuations that will never be justified."

Altman nevertheless insists bubbles form around real breakthroughs and says AI will still transform the economy.

He revealed OpenAI expects to invest "trillions of dollars" in data centre capacity over the next decade, betting that long-term gains will outweigh any short term market correction.

Analysts note the comment echoes 1990s internet optimism yet also signals how capital intensive frontier models have become.

For South Australians, an AI pull back could cool the state's blossoming tech precinct at Lot Fourteen, but Altman's infrastructure forecast still points to demand for local data centre sites and power.

Adelaide's renewable heavy grid could prove a selling point if global firms look beyond overheated US hubs.`,
                category: "Technology",
                source: "Perplexity.ai",
                link: "https://www.perplexity.ai/page/openai-ceo-admits-ai-bubble-wh-Oona2c9sTjy6vm837Nrx2g"
            },
            {
                title: "Putin Trump Alaska talks end without deal as war in Ukraine grinds on",
                content: `ABC News reports Russian President Vladimir Putin and former US leader Donald Trump spoke for nearly three hours at Elmendorf Air Force Base, Anchorage, seeking a face saving path to cease-fire.

While both sides called the mood "constructive," no agreements emerged, and fighting continued across eastern Ukraine the same day.

Observers say the unusual Alaska venue let Trump claim neutral ground while giving Putin a symbolic win by flying the Russian flag on US soil.

An image Kyiv swiftly condemned. White House officials, frozen out of planning, warned any back channel deal must respect Ukrainian sovereignty.

South Australia hosts a growing Ukrainian diaspora; local community groups fear "photo op diplomacy" risks undercutting allied resolve.

Premier Peter Malinauskas reaffirmed the state's commitment to settlement support and called for "nothing about Ukraine without Ukraine."`,
                category: "International",
                source: "ABC News",
                link: "https://www.abc.net.au/news/2025-08-16/putin-trump-talks-in-alaska-flag-russia-war-on-ukraine-continues/105662420"
            },
            {
                title: "Clashes outside Victorian Parliament at Women Will Speak rally",
                content: `Riot police intervened after a Women Will Speak gathering opposing transgender reforms met a larger counter protest in Melbourne's CBD.

Mounted officers and pepper spray were deployed as skirmishes broke out on Spring Street; four people were arrested for assault and refusing police directions.

Speakers, including US activist Kellie Jay Keen, addressed about 120 supporters before pro trans demonstrators surged forward chanting "trans rights are human rights."

Victoria Police later defended its heavy presence, citing pre rally online threats from fringe groups on both sides.

Although interstate, the incident echoes tensions seen outside Adelaide's Parliament House during March's Let Women Speak tour.

SA Police say they are reviewing protest management tactics and urge organisers to lodge notifications early to avoid similar flashpoints.`,
                category: "Social Issues",
                source: "7NEWS",
                link: "https://7news.com.au/news/women-will-speak-rally-against-transgender-rights-turns-violent-as-pro-trans-protestors-turn-up-in-melbourne-cbd-c-19702376"
            },
            {
                title: "The ultra wealthy have exploited Australia's tax system for too long",
                content: `In a Guardian opinion piece, economist Richard Denniss argues billionaires pay proportionally less tax than nurses and teachers, citing Treasury data that Australia loses tens of billions to legal avoidance schemes.

He calls for a 2% annual wealth levy on fortunes above $50 million and stricter rules on offshore trusts.

Denniss notes that while Labor's 15% super tax on balances above $3 million affects just 0.5% of accounts, the measure still raises $2 billion a year proof targeted reform works.

He warns without broader action the budget will struggle to fund aged care, health and housing programs.`,
                category: "Economy & Alternative Opinion",
                source: "The Guardian",
                link: "https://www.theguardian.com/commentisfree/2025/aug/16/the-ultra-wealthy-have-exploited-australias-tax-system-for-too-long-its-time-to-ensure-everyone-pays-their-fair-share"
            }
        ];

        try {
            // Post header with News emoji
            const headerText = `📰 <b>16th of August, Night News</b> ℹ️\n\n<i>Tonight's top stories from Adelaide and around the world</i>`;
            
            const channelHeader = await this.bot.telegram.sendMessage(
                this.config.sourceChannelId,
                headerText,
                {
                    parse_mode: 'HTML',
                    reply_markup: Markup.inlineKeyboard([[
                        Markup.button.url('📰 Add News Emoji Pack', 'https://t.me/addemoji/NewsEmoji')
                    ]]).reply_markup
                }
            );
            
            // Forward header to TBC
            await this.bot.telegram.forwardMessage(
                this.config.tbcGroupId,
                this.config.sourceChannelId,
                channelHeader.message_id,
                { message_thread_id: this.config.tbcTopicId }
            );
            
            await ctx.reply(`✅ Header posted: Message ${channelHeader.message_id}`);
            
            // Post articles
            for (const article of articles) {
                await this.postSingleArticle(article, ctx);
                await new Promise(resolve => setTimeout(resolve, 1500));
            }
            
            await ctx.reply('✅ Night news posting complete!');
            
        } catch (error) {
            console.error('Error posting night news:', error);
            await ctx.reply(`❌ Error: ${error.message}`);
        }
    }

    /**
     * Post single article to channel and TBC
     */
    async postSingleArticle(article, ctx) {
        try {
            const text = this.formatArticle(article);
            
            // Post to channel
            const channelMsg = await this.bot.telegram.sendMessage(
                this.config.sourceChannelId,
                text,
                {
                    parse_mode: 'HTML',
                    disable_web_page_preview: false
                }
            );
            
            // Add reactions
            await this.bot.telegram.editMessageReplyMarkup(
                this.config.sourceChannelId,
                channelMsg.message_id,
                null,
                this.createReactionKeyboard(channelMsg.message_id).reply_markup
            );
            
            // Forward to TBC
            const tbcMsg = await this.bot.telegram.forwardMessage(
                this.config.tbcGroupId,
                this.config.sourceChannelId,
                channelMsg.message_id,
                { message_thread_id: this.config.tbcTopicId }
            );
            
            // Try to add reactions to forwarded message
            try {
                await this.bot.telegram.editMessageReplyMarkup(
                    this.config.tbcGroupId,
                    tbcMsg.message_id,
                    null,
                    this.createReactionKeyboard(channelMsg.message_id).reply_markup
                );
            } catch (err) {
                // If can't edit, send reaction buttons separately
                await this.bot.telegram.sendMessage(
                    this.config.tbcGroupId,
                    '👇 React to this article:',
                    {
                        message_thread_id: this.config.tbcTopicId,
                        reply_to_message_id: tbcMsg.message_id,
                        reply_markup: this.createReactionKeyboard(channelMsg.message_id).reply_markup
                    }
                );
            }
            
            // Track mapping
            this.messageMap.set(channelMsg.message_id, {
                channelId: channelMsg.message_id,
                tbcId: tbcMsg.message_id,
                title: article.title
            });
            
            if (ctx) {
                await ctx.reply(`✅ Posted: "${article.title.substring(0, 50)}..." (Channel: ${channelMsg.message_id}, TBC: ${tbcMsg.message_id})`);
            }
            
            return { channelMsg, tbcMsg };
            
        } catch (error) {
            console.error('Error posting article:', error);
            if (ctx) {
                await ctx.reply(`❌ Failed to post article: ${error.message}`);
            }
            throw error;
        }
    }
}

module.exports = TBCNightNewsCommand;