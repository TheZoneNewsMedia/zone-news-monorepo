/**
 * Post Command Handler - Admin posting functionality
 */

const { Markup } = require('telegraf');
const { ObjectId } = require('mongodb');

class PostCommand {
    constructor(bot, db, postManager) {
        this.bot = bot;
        this.db = db;
        this.postManager = postManager;
    }
    
    async handle(ctx, args = []) {
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(ctx.from.id)) {
            return ctx.reply('❌ This command is for admins only.');
        }
        
        // Get destinations
        const destinations = await this.db.collection('destinations')
            .find({ active: true })
            .toArray();
        
        if (destinations.length === 0) {
            return ctx.reply(
                '📭 No destinations configured.\n\n' +
                'Add destinations with:\n' +
                '/add @channel_username\n' +
                '/add -100123456789 (group ID)'
            );
        }
        
        // Get recent articles
        const articles = await this.db.collection('news_articles')
            .find({})
            .sort({ published_date: -1 })
            .limit(10)
            .toArray();
        
        if (articles.length === 0) {
            return ctx.reply('📭 No articles available to post.');
        }
        
        // Store in session for wizard
        await this.db.collection('post_sessions').insertOne({
            user_id: ctx.from.id,
            articles: articles.map(a => ({
                _id: a._id,
                title: a.title,
                category: a.category
            })),
            destinations: destinations.map(d => ({
                _id: d._id,
                name: d.name || d.username || d.id,
                type: d.type
            })),
            created_at: new Date(),
            expires_at: new Date(Date.now() + 30 * 60 * 1000) // 30 min
        });
        
        // Show article selection
        const keyboard = articles.map((article, i) => [{
            text: `${i + 1}. ${this.truncate(article.title, 50)}`,
            callback_data: `post:article:${article._id}`
        }]);
        
        keyboard.push([{
            text: '❌ Cancel',
            callback_data: 'post:cancel'
        }]);
        
        await ctx.reply(
            '📰 *Select Article to Post*\n\n' +
            'Choose an article from the list below:',
            {
                parse_mode: 'Markdown',
                reply_markup: {
                    inline_keyboard: keyboard
                }
            }
        );
    }
    
    /**
     * Handle article selection
     */
    async handleArticleSelection(ctx, articleId) {
        const session = await this.db.collection('post_sessions')
            .findOne({ user_id: ctx.from.id });
        
        if (!session) {
            return ctx.answerCbQuery('Session expired. Please /post again.');
        }
        
        // Update session with selected article
        await this.db.collection('post_sessions').updateOne(
            { _id: session._id },
            { $set: { selected_article: articleId } }
        );
        
        // Show destination selection
        const keyboard = session.destinations.map(dest => [{
            text: `${dest.type === 'channel' ? '📢' : '👥'} ${dest.name}`,
            callback_data: `post:dest:${dest._id}`
        }]);
        
        // Add select all option
        keyboard.unshift([{
            text: '📡 Post to All',
            callback_data: 'post:dest:all'
        }]);
        
        keyboard.push([{
            text: '↩️ Back',
            callback_data: 'post:back:articles'
        }, {
            text: '❌ Cancel',
            callback_data: 'post:cancel'
        }]);
        
        await ctx.editMessageText(
            '📍 *Select Destination*\n\n' +
            'Where should this article be posted?',
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard(keyboard)
            }
        );
    }
    
    /**
     * Handle destination selection and post
     */
    async handleDestinationSelection(ctx, destinationId) {
        const session = await this.db.collection('post_sessions')
            .findOne({ user_id: ctx.from.id });
        
        if (!session || !session.selected_article) {
            return ctx.answerCbQuery('Session expired. Please /post again.');
        }
        
        await ctx.answerCbQuery('📤 Posting...');
        
        let destinations = [];
        
        if (destinationId === 'all') {
            destinations = session.destinations;
        } else {
            const dest = session.destinations.find(d => d._id.toString() === destinationId);
            if (dest) destinations = [dest];
        }
        
        if (destinations.length === 0) {
            return ctx.editMessageText('❌ No valid destinations found.');
        }
        
        // Post to each destination
        const results = [];
        for (const dest of destinations) {
            const result = await this.postManager.postArticle(
                session.selected_article,
                dest._id,
                ctx.from.id
            );
            
            results.push({
                destination: dest.name,
                ...result
            });
        }
        
        // Clean up session
        await this.db.collection('post_sessions').deleteOne({ _id: session._id });
        
        // Show results
        let message = '📤 *Posting Results*\n\n';
        let successCount = 0;
        
        for (const result of results) {
            if (result.success) {
                message += `✅ ${result.destination}\n`;
                successCount++;
            } else {
                message += `❌ ${result.destination}: ${result.error}\n`;
            }
        }
        
        message += `\n✨ Posted to ${successCount}/${results.length} destinations`;
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard([
                [Markup.button.callback('📰 Post Another', 'post:new')],
                [Markup.button.callback('✅ Done', 'post:done')]
            ])
        });
    }
    
    /**
     * Handle post with edit (for groups)
     */
    async handlePostWithEdit(ctx) {
        const session = await this.db.collection('post_sessions')
            .findOne({ user_id: ctx.from.id });
        
        if (!session) {
            return ctx.answerCbQuery('Session expired. Please /post again.');
        }
        
        await ctx.answerCbQuery('You can edit the message after posting');
        
        // Add edit capability flag
        await this.db.collection('post_sessions').updateOne(
            { _id: session._id },
            { $set: { allow_edit: true } }
        );
    }
    
    /**
     * Cancel posting
     */
    async handleCancel(ctx) {
        // Clean up session
        await this.db.collection('post_sessions').deleteOne({ user_id: ctx.from.id });
        
        await ctx.editMessageText('❌ Posting cancelled.');
        await ctx.answerCbQuery('Cancelled');
    }
    
    /**
     * Truncate text
     */
    truncate(text, maxLength) {
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength - 3) + '...';
    }
}

module.exports = PostCommand;