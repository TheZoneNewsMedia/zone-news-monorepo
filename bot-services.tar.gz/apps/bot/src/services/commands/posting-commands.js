/**
 * Posting Commands Module
 * Comprehensive posting functionality for channels, groups, and topics
 * Can post from private chat or within groups
 */

const { ObjectId } = require('mongodb');

class PostingCommands {
    constructor(bot, db, services = {}) {
        this.bot = bot;
        this.db = db;
        
        // Injected services
        this.stateService = services.stateService;
        this.adminService = services.adminService;
        this.postManager = services.postManager;
        
        // User states for interactive flows
        this.userStates = new Map();
    }

    /**
     * Register all posting commands
     */
    register() {
        // Main posting commands
        this.bot.command('post', this.handlePost.bind(this));
        this.bot.command('posttogroup', this.handlePostToGroup.bind(this));
        this.bot.command('posttochannel', this.handlePostToChannel.bind(this));
        this.bot.command('posttotopic', this.handlePostToTopic.bind(this));
        this.bot.command('posttext', this.handlePostText.bind(this));
        this.bot.command('quickpost', this.handleQuickPost.bind(this));
        
        // Destination management
        this.bot.command('addchannel', this.handleAddChannel.bind(this));
        this.bot.command('addgroup', this.handleAddGroup.bind(this));
        this.bot.command('addtopic', this.handleAddTopic.bind(this));
        this.bot.command('mydestinations', this.handleMyDestinations.bind(this));
        this.bot.command('removedest', this.handleRemoveDestination.bind(this));
        
        // Register callback handlers
        this.registerCallbacks();
    }

    /**
     * Register callback query handlers
     */
    registerCallbacks() {
        // Destination selection
        this.bot.action(/^select_dest:(.+):(\d+)$/, this.handleDestinationSelect.bind(this));
        
        // Article selection
        this.bot.action(/^select_article:(.+)$/, this.handleArticleSelect.bind(this));
        
        // Post confirmation
        this.bot.action(/^post_confirm:(.+)$/, this.handlePostConfirm.bind(this));
        this.bot.action('post_cancel', this.handlePostCancel.bind(this));
        
        // Navigation
        this.bot.action(/^next_article:(\d+)$/, this.handleNextArticle.bind(this));
        this.bot.action(/^prev_article:(\d+)$/, this.handlePrevArticle.bind(this));
        
        // Edit text
        this.bot.action('edit_text', this.handleEditText.bind(this));
        
        // Quick actions
        this.bot.action('add_destination', this.handleAddDestinationMenu.bind(this));
        this.bot.action('schedule_post', this.handleSchedulePost.bind(this));
    }

    /**
     * Main /post command - Interactive posting wizard
     */
    async handlePost(ctx) {
        const userId = ctx.from.id;
        
        // Check admin permissions
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply(
                '❌ *Admin Access Required*\\n\\n' +
                'You need admin permissions to post.\\n\\n' +
                '💎 Contact @TheZoneNews for access',
                { parse_mode: 'Markdown' }
            );
        }
        
        // Get all destinations (channels, groups, topics)
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        if (!destinations || destinations.destinations.length === 0) {
            return ctx.reply(
                '📭 *No Destinations Configured*\\n\\n' +
                'Add destinations first:\\n' +
                '• `/addchannel @channelname` - Add channel\\n' +
                '• `/addgroup` - Add group (use in group)\\n' +
                '• `/addtopic` - Add forum topic\\n\\n' +
                'Or use `/quickpost` to add and post in one step',
                { parse_mode: 'Markdown' }
            );
        }
        
        // Create destination selector
        const keyboard = {
            inline_keyboard: []
        };
        
        // Group destinations by type
        const channels = destinations.destinations.filter(d => d.type === 'channel');
        const groups = destinations.destinations.filter(d => d.type === 'group' || d.type === 'supergroup');
        const topics = destinations.destinations.filter(d => d.type === 'topic');
        
        // Add channels
        if (channels.length > 0) {
            keyboard.inline_keyboard.push([{ 
                text: '📢 CHANNELS', 
                callback_data: 'header_channels' 
            }]);
            channels.forEach(dest => {
                keyboard.inline_keyboard.push([{
                    text: `📢 ${dest.name}`,
                    callback_data: `select_dest:${dest.id}:0`
                }]);
            });
        }
        
        // Add groups
        if (groups.length > 0) {
            keyboard.inline_keyboard.push([{ 
                text: '👥 GROUPS', 
                callback_data: 'header_groups' 
            }]);
            groups.forEach(dest => {
                keyboard.inline_keyboard.push([{
                    text: `👥 ${dest.name}`,
                    callback_data: `select_dest:${dest.id}:0`
                }]);
            });
        }
        
        // Add topics
        if (topics.length > 0) {
            keyboard.inline_keyboard.push([{ 
                text: '💬 FORUM TOPICS', 
                callback_data: 'header_topics' 
            }]);
            topics.forEach(dest => {
                keyboard.inline_keyboard.push([{
                    text: `💬 ${dest.name}`,
                    callback_data: `select_dest:${dest.id}:${dest.topic_id}`
                }]);
            });
        }
        
        // Add action buttons
        keyboard.inline_keyboard.push([
            { text: '➕ Add Destination', callback_data: 'add_destination' },
            { text: '⏰ Schedule Post', callback_data: 'schedule_post' }
        ]);
        keyboard.inline_keyboard.push([
            { text: '❌ Cancel', callback_data: 'post_cancel' }
        ]);
        
        await ctx.reply(
            '📝 *Select Posting Destination*\\n\\n' +
            'Choose where to post your article:',
            { 
                parse_mode: 'Markdown', 
                reply_markup: keyboard 
            }
        );
    }

    /**
     * /posttogroup - Post to a specific group (can be used from private chat)
     */
    async handlePostToGroup(ctx) {
        const userId = ctx.from.id;
        const args = ctx.message.text.split(' ').slice(1);
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        // If used in a group, save it as destination
        if (ctx.chat.type !== 'private') {
            const groupId = ctx.chat.id;
            const groupName = ctx.chat.title;
            
            // Save to destinations
            await this.db.collection('admin_destinations').updateOne(
                { telegram_id: userId },
                { 
                    $addToSet: { 
                        destinations: {
                            id: groupId.toString(),
                            name: groupName,
                            type: ctx.chat.type,
                            added_at: new Date()
                        }
                    }
                },
                { upsert: true }
            );
            
            // Start posting flow
            this.userStates.set(userId, {
                destination: groupId.toString(),
                destinationName: groupName,
                topicId: null
            });
            
            await ctx.reply('✅ Group saved. Now select an article to post.');
            return this.showArticleSelection(ctx);
        }
        
        // If used in private chat, show group selector
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        const groups = destinations?.destinations.filter(d => 
            d.type === 'group' || d.type === 'supergroup'
        ) || [];
        
        if (groups.length === 0) {
            return ctx.reply(
                '📭 *No Groups Available*\\n\\n' +
                'Add groups first:\\n' +
                '1. Add bot to your group as admin\\n' +
                '2. Use `/addgroup` in the group\\n' +
                '3. Or provide group ID: `/posttogroup -100123456789`',
                { parse_mode: 'Markdown' }
            );
        }
        
        // Create group selector
        const keyboard = {
            inline_keyboard: groups.map(group => [{
                text: `👥 ${group.name}`,
                callback_data: `select_dest:${group.id}:0`
            }])
        };
        
        keyboard.inline_keyboard.push([
            { text: '❌ Cancel', callback_data: 'post_cancel' }
        ]);
        
        await ctx.reply(
            '👥 *Select Group*\\n\\n' +
            'Choose a group to post to:',
            { 
                parse_mode: 'Markdown', 
                reply_markup: keyboard 
            }
        );
    }

    /**
     * /posttochannel - Post to a specific channel
     */
    async handlePostToChannel(ctx) {
        const userId = ctx.from.id;
        const args = ctx.message.text.split(' ').slice(1);
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        // If channel specified, use it directly
        if (args.length > 0) {
            const channelId = args[0];
            
            // Validate channel format
            if (!channelId.startsWith('@') && !channelId.startsWith('-100')) {
                return ctx.reply(
                    '❌ Invalid channel format\\n\\n' +
                    'Use: `/posttochannel @channelname`\\n' +
                    'Or: `/posttochannel -1001234567890`',
                    { parse_mode: 'Markdown' }
                );
            }
            
            // Save state and proceed
            this.userStates.set(userId, {
                destination: channelId,
                destinationName: channelId,
                topicId: null
            });
            
            return this.showArticleSelection(ctx);
        }
        
        // Show channel selector
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        const channels = destinations?.destinations.filter(d => d.type === 'channel') || [];
        
        if (channels.length === 0) {
            return ctx.reply(
                '📭 *No Channels Available*\\n\\n' +
                'Add channels first:\\n' +
                '`/addchannel @channelname`',
                { parse_mode: 'Markdown' }
            );
        }
        
        const keyboard = {
            inline_keyboard: channels.map(channel => [{
                text: `📢 ${channel.name}`,
                callback_data: `select_dest:${channel.id}:0`
            }])
        };
        
        keyboard.inline_keyboard.push([
            { text: '❌ Cancel', callback_data: 'post_cancel' }
        ]);
        
        await ctx.reply(
            '📢 *Select Channel*\\n\\n' +
            'Choose a channel to post to:',
            { 
                parse_mode: 'Markdown', 
                reply_markup: keyboard 
            }
        );
    }

    /**
     * /posttotopic - Post to forum topics
     */
    async handlePostToTopic(ctx) {
        const userId = ctx.from.id;
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        // If used in a topic, save it
        if (ctx.chat.type !== 'private' && ctx.message.message_thread_id) {
            const groupId = ctx.chat.id;
            const topicId = ctx.message.message_thread_id;
            const groupName = ctx.chat.title;
            
            // Save to destinations
            await this.db.collection('admin_destinations').updateOne(
                { telegram_id: userId },
                { 
                    $addToSet: { 
                        destinations: {
                            id: groupId.toString(),
                            name: `${groupName} - Topic ${topicId}`,
                            type: 'topic',
                            topic_id: topicId,
                            added_at: new Date()
                        }
                    }
                },
                { upsert: true }
            );
            
            // Start posting flow
            this.userStates.set(userId, {
                destination: groupId.toString(),
                destinationName: `${groupName} - Topic ${topicId}`,
                topicId: topicId
            });
            
            await ctx.reply('✅ Topic saved. Now select an article to post.');
            return this.showArticleSelection(ctx);
        }
        
        // Show topic selector
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        const topics = destinations?.destinations.filter(d => d.type === 'topic') || [];
        
        if (topics.length === 0) {
            return ctx.reply(
                '📭 *No Forum Topics Available*\\n\\n' +
                'Add topics first:\\n' +
                '1. Go to a forum group\\n' +
                '2. Enter a specific topic thread\\n' +
                '3. Use `/addtopic` command',
                { parse_mode: 'Markdown' }
            );
        }
        
        const keyboard = {
            inline_keyboard: topics.map(topic => [{
                text: `💬 ${topic.name}`,
                callback_data: `select_dest:${topic.id}:${topic.topic_id}`
            }])
        };
        
        keyboard.inline_keyboard.push([
            { text: '❌ Cancel', callback_data: 'post_cancel' }
        ]);
        
        await ctx.reply(
            '💬 *Select Forum Topic*\\n\\n' +
            'Choose a topic to post to:',
            { 
                parse_mode: 'Markdown', 
                reply_markup: keyboard 
            }
        );
    }

    /**
     * /posttext - Set custom post text
     */
    async handlePostText(ctx) {
        const userId = ctx.from.id;
        const text = ctx.message.text.replace('/posttext', '').trim();
        
        if (!text) {
            return ctx.reply(
                '✏️ *Custom Post Text*\\n\\n' +
                'Usage: `/posttext Your custom message here`\\n\\n' +
                'This text will be used for your next post.',
                { parse_mode: 'Markdown' }
            );
        }
        
        // Store custom text in user state
        const currentState = this.userStates.get(userId) || {};
        currentState.customText = text;
        this.userStates.set(userId, currentState);
        
        await ctx.reply(
            '✅ *Custom text saved!*\\n\\n' +
            'This will be used for your next post.\\n' +
            'Use `/post` to continue.',
            { parse_mode: 'Markdown' }
        );
    }

    /**
     * /quickpost - One-command posting
     */
    async handleQuickPost(ctx) {
        const userId = ctx.from.id;
        const args = ctx.message.text.split(' ').slice(1);
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        if (args.length < 1) {
            return ctx.reply(
                '⚡ *Quick Post*\\n\\n' +
                'Usage:\\n' +
                '`/quickpost @channel` - Post latest article to channel\\n' +
                '`/quickpost -100123456789` - Post to group by ID\\n' +
                '`/quickpost all` - Post to all destinations',
                { parse_mode: 'Markdown' }
            );
        }
        
        // Get latest article
        const article = await this.db.collection('news_articles')
            .findOne({}, { sort: { published_date: -1 } });
        
        if (!article) {
            return ctx.reply('📭 No articles available');
        }
        
        const destination = args[0];
        
        // Handle "all" destinations
        if (destination === 'all') {
            const destinations = await this.db.collection('admin_destinations')
                .findOne({ telegram_id: userId });
            
            if (!destinations || destinations.destinations.length === 0) {
                return ctx.reply('📭 No destinations configured');
            }
            
            let successCount = 0;
            let failedCount = 0;
            
            for (const dest of destinations.destinations) {
                try {
                    await this.postManager.postArticle(
                        article._id.toString(),
                        dest.id,
                        userId
                    );
                    successCount++;
                } catch (error) {
                    failedCount++;
                    console.error(`Failed to post to ${dest.name}:`, error);
                }
            }
            
            return ctx.reply(
                `✅ Posted to ${successCount} destinations\\n` +
                `${failedCount > 0 ? `❌ Failed: ${failedCount}` : ''}`
            );
        }
        
        // Post to specific destination
        try {
            await this.postManager.postArticle(
                article._id.toString(),
                destination,
                userId
            );
            
            await ctx.reply('✅ Article posted successfully!');
        } catch (error) {
            await ctx.reply(`❌ Failed to post: ${error.message}`);
        }
    }

    /**
     * Show article selection menu
     */
    async showArticleSelection(ctx) {
        const userId = ctx.from?.id || ctx.callbackQuery?.from.id;
        
        // Get latest articles
        const articles = await this.db.collection('news_articles')
            .find({})
            .sort({ published_date: -1 })
            .limit(10)
            .toArray();
        
        if (articles.length === 0) {
            return ctx.reply('📭 No articles available');
        }
        
        // Create article selector
        const keyboard = {
            inline_keyboard: articles.map((article, index) => [{
                text: `${index + 1}. ${article.title.substring(0, 50)}${article.title.length > 50 ? '...' : ''}`,
                callback_data: `select_article:${article._id}`
            }])
        };
        
        keyboard.inline_keyboard.push([
            { text: '✏️ Custom Text', callback_data: 'edit_text' },
            { text: '❌ Cancel', callback_data: 'post_cancel' }
        ]);
        
        const message = '📰 *Select Article*\\n\\n' +
                       'Choose an article to post:';
        
        // Edit or send based on context
        if (ctx.callbackQuery) {
            await ctx.editMessageText(message, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        } else {
            await ctx.reply(message, {
                parse_mode: 'Markdown',
                reply_markup: keyboard
            });
        }
    }

    /**
     * Handle destination selection
     */
    async handleDestinationSelect(ctx) {
        const userId = ctx.callbackQuery.from.id;
        const [destinationId, topicId] = ctx.match.slice(1);
        
        // Get destination details
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        const destination = destinations?.destinations.find(d => d.id === destinationId);
        
        if (!destination) {
            return ctx.answerCbQuery('❌ Destination not found');
        }
        
        // Save state
        this.userStates.set(userId, {
            destination: destinationId,
            destinationName: destination.name,
            topicId: topicId !== '0' ? parseInt(topicId) : null
        });
        
        await ctx.answerCbQuery(`✅ Selected: ${destination.name}`);
        
        // Show article selection
        return this.showArticleSelection(ctx);
    }

    /**
     * Handle article selection
     */
    async handleArticleSelect(ctx) {
        const userId = ctx.callbackQuery.from.id;
        const articleId = ctx.match[1];
        
        // Get article
        const article = await this.db.collection('news_articles')
            .findOne({ _id: new ObjectId(articleId) });
        
        if (!article) {
            return ctx.answerCbQuery('❌ Article not found');
        }
        
        // Get user state
        const state = this.userStates.get(userId);
        if (!state) {
            return ctx.answerCbQuery('❌ Please start with /post command');
        }
        
        // Update state with article
        state.article = article;
        state.articleIndex = 0;
        this.userStates.set(userId, state);
        
        // Show preview
        await this.showArticlePreview(ctx, article, state);
    }

    /**
     * Show article preview before posting
     */
    async showArticlePreview(ctx, article, state) {
        const customText = state.customText;
        
        // Format preview message
        let message = customText || this.formatArticle(article);
        
        const preview = 
            `📝 *Preview*\\n\\n` +
            `📍 Destination: ${state.destinationName}\\n` +
            `${state.topicId ? `💬 Topic ID: ${state.topicId}\\n` : ''}` +
            `━━━━━━━━━━━━━━━━━━━━\\n\\n` +
            `${this.escapeMarkdown(message.substring(0, 500))}${message.length > 500 ? '...' : ''}`;
        
        const keyboard = {
            inline_keyboard: [
                [
                    { text: '✅ Post Now', callback_data: `post_confirm:${article._id}` },
                    { text: '✏️ Edit Text', callback_data: 'edit_text' }
                ],
                [
                    { text: '⬅️ Previous', callback_data: `prev_article:0` },
                    { text: '➡️ Next', callback_data: `next_article:0` }
                ],
                [
                    { text: '❌ Cancel', callback_data: 'post_cancel' }
                ]
            ]
        };
        
        await ctx.editMessageText(preview, {
            parse_mode: 'Markdown',
            reply_markup: keyboard
        });
    }

    /**
     * Handle post confirmation
     */
    async handlePostConfirm(ctx) {
        const userId = ctx.callbackQuery.from.id;
        const articleId = ctx.match[1];
        
        const state = this.userStates.get(userId);
        if (!state) {
            return ctx.answerCbQuery('❌ Session expired. Please start again.');
        }
        
        try {
            // Post using PostManager
            const result = await this.postManager.postArticle(
                articleId,
                state.destination,
                userId,
                {
                    topicId: state.topicId,
                    customText: state.customText
                }
            );
            
            // Clear state
            this.userStates.delete(userId);
            
            await ctx.editMessageText(
                '✅ *Posted Successfully!*\\n\\n' +
                `📍 Destination: ${state.destinationName}\\n` +
                `📰 Article: ${state.article.title}\\n\\n` +
                'Use `/post` to post another article.',
                { parse_mode: 'Markdown' }
            );
            
        } catch (error) {
            console.error('Post error:', error);
            await ctx.answerCbQuery(`❌ Failed: ${error.message}`, true);
        }
    }

    /**
     * Handle post cancellation
     */
    async handlePostCancel(ctx) {
        const userId = ctx.callbackQuery.from.id;
        
        // Clear state
        this.userStates.delete(userId);
        
        await ctx.editMessageText('❌ Posting cancelled');
        await ctx.answerCbQuery('Cancelled');
    }

    /**
     * /addchannel - Add channel destination
     */
    async handleAddChannel(ctx) {
        const userId = ctx.from.id;
        const args = ctx.message.text.split(' ').slice(1);
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        if (args.length === 0) {
            return ctx.reply(
                '📢 *Add Channel*\\n\\n' +
                'Usage: `/addchannel @channelname`\\n\\n' +
                'Make sure:\\n' +
                '1. Bot is admin in the channel\\n' +
                '2. Bot has posting permissions',
                { parse_mode: 'Markdown' }
            );
        }
        
        const channelId = args[0];
        const customName = args.slice(1).join(' ') || channelId;
        
        // Save to destinations
        await this.db.collection('admin_destinations').updateOne(
            { telegram_id: userId },
            { 
                $addToSet: { 
                    destinations: {
                        id: channelId,
                        name: customName,
                        type: 'channel',
                        added_at: new Date()
                    }
                }
            },
            { upsert: true }
        );
        
        await ctx.reply(
            `✅ Channel added: ${customName}\\n\\n` +
            'Use `/post` to start posting!',
            { parse_mode: 'Markdown' }
        );
    }

    /**
     * /addgroup - Add group destination
     */
    async handleAddGroup(ctx) {
        const userId = ctx.from.id;
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        // Must be used in a group
        if (ctx.chat.type === 'private') {
            return ctx.reply(
                '👥 *Add Group*\\n\\n' +
                'This command must be used IN the group you want to add.\\n\\n' +
                'Steps:\\n' +
                '1. Add bot to your group\\n' +
                '2. Make bot admin\\n' +
                '3. Use `/addgroup` in the group',
                { parse_mode: 'Markdown' }
            );
        }
        
        const groupId = ctx.chat.id;
        const groupName = ctx.chat.title;
        const groupType = ctx.chat.type;
        
        // Save to destinations
        await this.db.collection('admin_destinations').updateOne(
            { telegram_id: userId },
            { 
                $addToSet: { 
                    destinations: {
                        id: groupId.toString(),
                        name: groupName,
                        type: groupType,
                        added_at: new Date()
                    }
                }
            },
            { upsert: true }
        );
        
        await ctx.reply(
            `✅ Group added: ${groupName}\\n\\n` +
            'You can now post here from private chat using `/post`!',
            { parse_mode: 'Markdown' }
        );
    }

    /**
     * /addtopic - Add forum topic
     */
    async handleAddTopic(ctx) {
        const userId = ctx.from.id;
        
        // Check admin
        const adminIds = process.env.ADMIN_IDS?.split(',').map(id => parseInt(id)) || [];
        if (!adminIds.includes(userId)) {
            return ctx.reply('❌ Admin access required');
        }
        
        // Must be used in a topic
        if (ctx.chat.type === 'private' || !ctx.message.message_thread_id) {
            return ctx.reply(
                '💬 *Add Forum Topic*\\n\\n' +
                'This command must be used IN the forum topic.\\n\\n' +
                'Steps:\\n' +
                '1. Go to a forum group\\n' +
                '2. Enter specific topic thread\\n' +
                '3. Use `/addtopic` command',
                { parse_mode: 'Markdown' }
            );
        }
        
        const groupId = ctx.chat.id;
        const topicId = ctx.message.message_thread_id;
        const groupName = ctx.chat.title;
        
        // Save to destinations
        await this.db.collection('admin_destinations').updateOne(
            { telegram_id: userId },
            { 
                $addToSet: { 
                    destinations: {
                        id: groupId.toString(),
                        name: `${groupName} - Topic ${topicId}`,
                        type: 'topic',
                        topic_id: topicId,
                        added_at: new Date()
                    }
                }
            },
            { upsert: true }
        );
        
        await ctx.reply(
            `✅ Topic added: ${groupName} - Topic ${topicId}\\n\\n` +
            'You can now post here using `/posttotopic`!',
            { parse_mode: 'Markdown' }
        );
    }

    /**
     * /mydestinations - List all destinations
     */
    async handleMyDestinations(ctx) {
        const userId = ctx.from.id;
        
        const destinations = await this.db.collection('admin_destinations')
            .findOne({ telegram_id: userId });
        
        if (!destinations || destinations.destinations.length === 0) {
            return ctx.reply('📭 No destinations configured. Use `/addchannel`, `/addgroup`, or `/addtopic` to add some.');
        }
        
        let message = '📍 *Your Destinations*\\n\\n';
        
        // Group by type
        const channels = destinations.destinations.filter(d => d.type === 'channel');
        const groups = destinations.destinations.filter(d => d.type === 'group' || d.type === 'supergroup');
        const topics = destinations.destinations.filter(d => d.type === 'topic');
        
        if (channels.length > 0) {
            message += '*📢 Channels:*\\n';
            channels.forEach((d, i) => {
                message += `${i + 1}. ${d.name}\\n`;
            });
            message += '\\n';
        }
        
        if (groups.length > 0) {
            message += '*👥 Groups:*\\n';
            groups.forEach((d, i) => {
                message += `${i + 1}. ${d.name}\\n`;
            });
            message += '\\n';
        }
        
        if (topics.length > 0) {
            message += '*💬 Forum Topics:*\\n';
            topics.forEach((d, i) => {
                message += `${i + 1}. ${d.name}\\n`;
            });
            message += '\\n';
        }
        
        message += `Total: ${destinations.destinations.length} destinations\\n\\n`;
        message += 'Use `/removedest` to remove destinations';
        
        await ctx.reply(message, { parse_mode: 'Markdown' });
    }

    /**
     * Format article for posting
     */
    formatArticle(article) {
        const date = new Date(article.published_date).toLocaleDateString('en-AU');
        
        return `📰 *${this.escapeMarkdown(article.title)}*\\n\\n` +
            `${this.escapeMarkdown(article.summary || article.content?.substring(0, 300))}...\\n\\n` +
            `📅 ${date} | 📂 ${article.category || 'General'}\\n` +
            `🔗 [Read More](${article.url || 'https://thezonenews.com'})`;
    }

    /**
     * Escape markdown special characters
     */
    escapeMarkdown(text) {
        if (!text) return '';
        return text.replace(/[*_`\[\]()]/g, '\\\\$&');
    }
}

module.exports = PostingCommands;