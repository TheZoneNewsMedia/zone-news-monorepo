/**
 * News Command Handler
 */

const { Markup } = require('telegraf');
const Formatter = require('../../utils/formatter');

class NewsCommand {
    constructor(bot, db, paginationService, postManager) {
        this.bot = bot;
        this.db = db;
        this.paginationService = paginationService;
        this.postManager = postManager;
    }
    
    async handle(ctx, args = []) {
        const userId = ctx.from.id;
        const category = args[0] || null;
        
        // Get user preferences
        const user = await this.db.collection('users').findOne({ user_id: userId });
        const userCity = user?.city || 'Adelaide';
        const userCategories = user?.categories || ['general'];
        
        // Build query
        const query = {};
        if (category) {
            query.category = category;
        } else if (userCategories.length > 0 && !userCategories.includes('all')) {
            query.category = { $in: userCategories };
        }
        
        // Add city filter if not 'all'
        if (userCity !== 'all') {
            query.$or = [
                { city: userCity },
                { city: { $exists: false } }
            ];
        }
        
        // Get paginated articles
        const result = await this.paginationService.getPaginatedArticles(userId, 1, query);
        
        if (result.articles.length === 0) {
            return ctx.reply(
                '📭 No news articles found.\n\n' +
                'Try:\n' +
                '• /news - All news\n' +
                '• /news technology - Tech news\n' +
                '• /settings - Change your preferences'
            );
        }
        
        // Format articles
        let message = `📰 *Latest News*`;
        if (category) {
            message += ` - ${category.charAt(0).toUpperCase() + category.slice(1)}`;
        }
        message += `\n\n`;
        
        result.articles.forEach((article, i) => {
            message += `${i + 1}. ${Formatter.formatArticle(article)}\n\n`;
        });
        
        // Add stats
        message += `📊 Showing ${result.articles.length} of ${result.totalCount} articles`;
        
        // Create pagination keyboard
        const keyboard = [];
        
        // Add pagination if needed
        if (result.totalPages > 1) {
            keyboard.push(...this.paginationService.generatePaginationKeyboard(
                result.currentPage,
                result.totalPages,
                'news:page'
            ));
        }
        
        // Add category filters
        const categoryButtons = [
            Markup.button.callback('💼 Business', 'news:cat:business'),
            Markup.button.callback('🎯 Sports', 'news:cat:sports'),
            Markup.button.callback('💻 Tech', 'news:cat:technology')
        ];
        keyboard.push(categoryButtons);
        
        // Add action buttons
        keyboard.push([
            Markup.button.callback('🔄 Refresh', 'news:refresh'),
            Markup.button.callback('🔍 Search', 'search:start'),
            Markup.button.callback('⚙️ Settings', 'settings:main')
        ]);
        
        await ctx.reply(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard),
            disable_web_page_preview: true
        });
    }
    
    /**
     * Handle category filter
     */
    async handleCategoryFilter(ctx, category) {
        const userId = ctx.from.id;
        
        const query = { category };
        const result = await this.paginationService.getPaginatedArticles(userId, 1, query);
        
        if (result.articles.length === 0) {
            return ctx.answerCbQuery(`No ${category} news found`, { show_alert: true });
        }
        
        let message = `📰 *${category.charAt(0).toUpperCase() + category.slice(1)} News*\n\n`;
        
        result.articles.forEach((article, i) => {
            message += `${i + 1}. ${Formatter.formatArticle(article)}\n\n`;
        });
        
        const keyboard = [];
        
        if (result.totalPages > 1) {
            keyboard.push(...this.paginationService.generatePaginationKeyboard(
                result.currentPage,
                result.totalPages,
                `news:${category}:page`
            ));
        }
        
        keyboard.push([
            Markup.button.callback('↩️ All News', 'news:all'),
            Markup.button.callback('🔄 Refresh', `news:cat:${category}`)
        ]);
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard),
            disable_web_page_preview: true
        });
        
        await ctx.answerCbQuery(`Showing ${category} news`);
    }
    
    /**
     * Handle refresh
     */
    async handleRefresh(ctx) {
        await ctx.answerCbQuery('🔄 Refreshing...');
        
        // Delete message and send new one
        try {
            await ctx.deleteMessage();
        } catch (e) {
            // Ignore if can't delete
        }
        
        // Send fresh news
        await this.handle(ctx);
    }
    
    /**
     * Handle pagination
     */
    async handlePagination(ctx, page, category = null) {
        const result = await this.paginationService.handlePageNavigation(ctx, page);
        
        if (!result) return;
        
        let message = `📰 *Latest News*`;
        if (category) {
            message += ` - ${category.charAt(0).toUpperCase() + category.slice(1)}`;
        }
        message += ` (Page ${result.currentPage}/${result.totalPages})\n\n`;
        
        result.articles.forEach((article, i) => {
            const num = (result.currentPage - 1) * 5 + i + 1;
            message += `${num}. ${Formatter.formatArticle(article)}\n\n`;
        });
        
        const keyboard = this.paginationService.generatePaginationKeyboard(
            result.currentPage,
            result.totalPages,
            category ? `news:${category}:page` : 'news:page'
        );
        
        await ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard),
            disable_web_page_preview: true
        });
    }
}

module.exports = NewsCommand;