/**
 * Database Service
 */

const { MongoClient } = require('mongodb');

class DatabaseService {
    static async connect(uri) {
        const client = await MongoClient.connect(uri);
        const db = client.db('zone_news_production');
        
        // Create indexes
        await this.createIndexes(db);
        
        return db;
    }
    
    static async createIndexes(db) {
        try {
            // News articles indexes - wrap each in try-catch
            try {
                await db.collection('news_articles').createIndex({ published_date: -1 });
            } catch (err) {
                if (err.code !== 85 && err.code !== 86) {
                    console.log('Index error (published_date):', err.message);
                }
            }
            
            // Text search index - skip if any text index already exists
            try {
                const indexes = await db.collection('news_articles').indexes();
                const hasTextIndex = indexes.some(idx => idx.key._fts === 'text');
                
                if (!hasTextIndex) {
                    await db.collection('news_articles').createIndex({ 
                        title: 'text', 
                        content: 'text' 
                    });
                }
            } catch (err) {
                // Silently skip text index errors
                console.log('Text index already exists, skipping');
            }
            
            // Destinations index
            try {
                await db.collection('destinations').createIndex({ type: 1 });
            } catch (err) {
                if (err.code !== 85 && err.code !== 86) {
                    console.log('Index error (destinations):', err.message);
                }
            }
            
            // Admin indexes
            try {
                await db.collection('bot_admins').createIndex({ telegram_id: 1 });
            } catch (err) {
                if (err.code !== 85 && err.code !== 86) {
                    console.log('Index error (bot_admins):', err.message);
                }
            }
            
            try {
                await db.collection('channel_admins').createIndex({ 
                    channel_id: 1, 
                    telegram_id: 1 
                });
            } catch (err) {
                if (err.code !== 85 && err.code !== 86) {
                    console.log('Index error (channel_admins):', err.message);
                }
            }
            
            console.log('✅ Database indexes configured');
        } catch (error) {
            console.log('Index creation warning:', error.message);
        }
    }
}

module.exports = DatabaseService;